import os
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d



class ImprovedAttentionMultiOutputNet(nn.Module):
    """
    改进的注意力机制多输出网络
    根据领域知识，为不同输出使用不同的注意力机制：
    - 电池温度预测：更关注环境温度
    - 效率预测：更关注充电功率
    """
    
    def __init__(self, input_size=3, attention_hidden_size=64, shared_layer_sizes=None, temp_layer_sizes=None, eff_layer_sizes=None):
        super(ImprovedAttentionMultiOutputNet, self).__init__()
        
        # 为电池温度预测设计的注意力层（更关注环境温度）
        self.temp_attention = nn.Sequential(
            nn.Linear(input_size, attention_hidden_size),
            nn.Tanh(),
            nn.Linear(attention_hidden_size, input_size),
            nn.Softmax(dim=1)
        )
        
        # 为效率预测设计的注意力层（更关注充电功率）
        self.eff_attention = nn.Sequential(
            nn.Linear(input_size, attention_hidden_size),
            nn.Tanh(),
            nn.Linear(attention_hidden_size, input_size),
            nn.Softmax(dim=1)
        )
        
        # 真正的共享特征提取层（温度和效率预测共享相同的权重）
        shared_layers = []
        shared_in_features = input_size
        for i, out_features in enumerate(shared_layer_sizes):
            shared_layers.append(nn.Linear(shared_in_features, out_features))
            shared_layers.append(nn.ReLU())
            shared_in_features = out_features
        
        self.shared_layers = nn.Sequential(*shared_layers)
        
        # 电池温度预测分支
        temp_layers = []
        temp_in_features = shared_layer_sizes[-1]  # 来自共享层的输出
        for i, out_features in enumerate(temp_layer_sizes):
            temp_layers.append(nn.Linear(temp_in_features, out_features))
            if i < len(temp_layer_sizes) - 1:  # 不是最后一层
                temp_layers.append(nn.ReLU())
            temp_in_features = out_features
        
        self.temp_branch = nn.Sequential(*temp_layers)
        
        # 效率预测分支 (使用预测的电池温度替换环境温度)
        eff_layers = []
        eff_in_features = shared_layer_sizes[-1]  # 共享特征，不包含额外输入
        for i, out_features in enumerate(eff_layer_sizes):
            eff_layers.append(nn.Linear(eff_in_features, out_features))
            if i < len(eff_layer_sizes) - 1:  # 不是最后一层
                eff_layers.append(nn.ReLU())
            eff_in_features = out_features
        
        self.efficiency_branch = nn.Sequential(*eff_layers)
    
    def forward(self, x):  
        temp_attention_weights = self.temp_attention(x)
        temp_attended_input = x * temp_attention_weights
        
        # 使用电池温度注意力权重提取共享特征
        temp_shared_features = self.shared_layers(temp_attended_input)
        
        # 预测电池温度
        battery_temp = self.temp_branch(temp_shared_features)
        
        # 创建用于效率预测的修改输入：用预测的电池温度替换环境温度
        # 原始输入: [SOC, ChargingPower, AmbientTemp]
        # 修改后: [SOC, ChargingPower, PredictedBatteryTemp]
        modified_input = torch.cat([x[:, :2], battery_temp], dim=1)  # 保留SOC和Power，用预测温度替换环境温度
        
        # 效率预测路径的注意力机制（基于修改后的输入）
        eff_attention_weights = self.eff_attention(modified_input)
        eff_attended_input = modified_input * eff_attention_weights
        
        # 使用效率注意力权重提取共享特征（使用相同的共享层）
        eff_shared_features = self.shared_layers(eff_attended_input)
        
        # 预测效率
        efficiency = self.efficiency_branch(eff_shared_features)
        
        return battery_temp, efficiency, temp_attention_weights, eff_attention_weights

# === Load Model and Scalers ===
# 使用与训练时相同的网络架构参数
model = ImprovedAttentionMultiOutputNet(
    input_size=3,
    attention_hidden_size=95,  # 优化的注意力隐藏层大小
    shared_layer_sizes=[107, 114, 81],  # 优化的共享层（3层）
    temp_layer_sizes=[120, 121, 1],  # 优化的温度分支
    eff_layer_sizes=[38, 1]  # 优化的效率分支
)
model.load_state_dict(torch.load("Model_Improved_Attention_charging_best.sd", map_location='cpu'))
model.eval()
input_scaler = joblib.load("scaler_improved_attention_input.pkl")
output_scaler = joblib.load("scaler_improved_attention_output.pkl")

# === Simulation Settings ===
synthetic_files = ["synthetic_data_4.csv", "synthetic_data_7.csv", "synthetic_data_6.csv"]
#synthetic_files = ["synthetic_power_11kW_2.csv", "synthetic_power_4kW_2.csv", "synthetic_power_8kW_2.csv"]
FULL_POWER_RANGE = np.linspace(1.5, 11.0, 10)
TOP_N_CANDIDATES = 10
BATTERY_CAPACITY_KWH = 60

# === Prepare Figure with 3 Subplots ===
fig, axs = plt.subplots(nrows=1, ncols=3, figsize=(9, 2.5), sharex=False)

# === Begin processing each file ===
for i, file in enumerate(synthetic_files):
    if not os.path.exists(file):
        print(f"{file} is missing.")
        continue

    df = pd.read_csv(file).rename(columns={
        'ChargeLinePower264': 'p_ac',
        'SOCave292': 'SoC',
        'VCRIGHT_tempAmbientRaw': 'T_amb'
    }).dropna(subset=['p_ac', 'SoC', 'T_amb']).reset_index(drop=True)

    session_len_sec = len(df)
    if session_len_sec < 60:
        print(f"{file} is too short.")
        continue

    num_minutes = session_len_sec // 60
    SoC = df.loc[0, 'SoC']
    T_amb_init = df.loc[0, 'T_amb']

    # Step 1: Choose Top Power Candidates (based on initial T_amb)
    power_scores = []
    for p_ac in FULL_POWER_RANGE:
        input_arr = np.array([[SoC, p_ac, T_amb_init]])
        input_scaled = input_scaler.transform(input_arr)
        input_tensor = torch.tensor(input_scaled, dtype=torch.float32)
        with torch.no_grad():
            bt, eff, _, _ = model(input_tensor)
            output = torch.cat([bt, eff], dim=1).numpy()
            output_unscaled = output_scaler.inverse_transform(output)
        temp_pred, eff_pred = output_unscaled.flatten()
        score = eff_pred - max(0, temp_pred - 35) * 0.5
        power_scores.append((p_ac, score))

    sorted_candidates = sorted(power_scores, key=lambda x: x[1], reverse=True)
    POWER_CANDIDATES_KW = np.array([p[0] for p in sorted_candidates[:TOP_N_CANDIDATES]])

    # Step 2: Optimize for entire session
    optimized_power_profile = []
    predicted_eff_list = []
    predicted_temp_list = []
    actual_amb_temp_list = []

    for t in range(num_minutes):
        idx = t * 60
        if idx >= session_len_sec:
            break

        T_amb = df.loc[idx, 'T_amb']
        actual_amb_temp_list.append(T_amb)

        best_score = -np.inf
        best_power = 0
        best_eff = 0
        best_temp = 0

        for p_ac in POWER_CANDIDATES_KW:
            input_arr = np.array([[SoC, p_ac, T_amb]])
            input_scaled = input_scaler.transform(input_arr)
            input_tensor = torch.tensor(input_scaled, dtype=torch.float32)
            with torch.no_grad():
                bt, eff, _, _ = model(input_tensor)
                output = torch.cat([bt, eff], dim=1).numpy()
                output_unscaled = output_scaler.inverse_transform(output)
            temp_val, eff_val = output_unscaled.flatten()
            score = eff_val - max(0, temp_val - 35) * 0.5
            if score > best_score:
                best_score = score
                best_power = p_ac
                best_eff = eff_val
                best_temp = temp_val

        optimized_power_profile.append(best_power)
        predicted_eff_list.append(best_eff)
        predicted_temp_list.append(best_temp)
        SoC += best_power / BATTERY_CAPACITY_KWH * (1 / 60) * 100
        SoC = min(SoC, 100)

    # Step 3: Plot full session
    ax = axs[i]
    time_sec = np.linspace(0, num_minutes - 1, session_len_sec)
    raw_power = df['p_ac'].values[:session_len_sec]

    # Interpolate optimized power to full second-level resolution
    interp_func = interp1d(np.arange(num_minutes), optimized_power_profile, kind='linear')
    opt_1s = interp_func(time_sec)

    # Compute energy
    raw_energy_kWh = np.sum(raw_power) / 3600
    opt_energy_kWh = np.sum(opt_1s) / 3600

    # Plot power curves (left Y-axis)
    ax.plot(time_sec, raw_power, label=f"Raw ({raw_energy_kWh:.2f} kWh)", color='black', linewidth=1.5)
    ax.plot(time_sec, opt_1s, label=f"Optimized ({opt_energy_kWh:.2f} kWh)", color='green', linewidth=1.5)
    ax.set_ylabel("Power (kW)")
    ax.set_xlabel("Time (minutes)")
    ax.grid(True)

    # Right Y-axis: predicted and ambient temperature
    ax2 = ax.twinx()
    ax2.plot(np.arange(num_minutes), predicted_temp_list, color='orange', linestyle='--', linewidth=1.2, label="Battery Temp (°C)")
    ax2.plot(np.arange(num_minutes), actual_amb_temp_list, color='red', linestyle=':', linewidth=1.2, label="Ambient Temp (°C)")
    ax2.set_ylabel("Temperature (°C)")
    ax2.set_ylim(0, max(40, max(predicted_temp_list + actual_amb_temp_list) + 5))

    # Combined legend
    lines1, labels1 = ax.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax.legend(lines1 + lines2, labels1 + labels2, loc="lower right", fontsize=7)



# === Finalize the full figure ===
axs[0].set_xlabel("Time (minutes)")
axs[1].set_xlabel("Time (minutes)")
axs[2].set_xlabel("Time (minutes)")
axs[0].set_ylim(0, 12)
axs[1].set_ylim(0, 12)
axs[2].set_ylim(0, 12)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()
