##############################################################################
### Correlation Analysis for Standard_data_unique.csv
### Author: Fanghao Tian
### Date: 2024-Oct-30
##############################################################################

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from scipy import stats

# Set up the output folder
outputfolder = 'OutputData'

# Load the data
print("Loading data...")
data = pd.read_csv(os.path.join(outputfolder, 'Standard_data_unique.csv'))
print(f"Data shape: {data.shape}")
print(f"Columns: {data.columns.tolist()}")
print("\nData head:")
print(data.head())

# Basic statistics
print("\nBasic statistics:")
print(data.describe())

# Create correlation matrix
print("\nCalculating correlation matrix...")
correlation_matrix = data.corr()

# Create a comprehensive correlation analysis plot
plt.figure(figsize=(15, 12))

# 1. Correlation heatmap
plt.subplot(2, 2, 1)
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0, 
            square=True, fmt='.3f', cbar_kws={'shrink': 0.8})
plt.title('Correlation Heatmap', fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=0)

# 2. Correlation bar plot (absolute values)
plt.subplot(2, 2, 2)
# Get absolute correlation values and sort them
abs_corr = correlation_matrix.abs().unstack()
abs_corr = abs_corr[abs_corr != 1.0]  # Remove self-correlations
abs_corr = abs_corr.sort_values(ascending=False)
# Plot top 10 correlations
top_corr = abs_corr.head(10)
plt.barh(range(len(top_corr)), top_corr.values)
plt.yticks(range(len(top_corr)), [f"{idx[0]} vs {idx[1]}" for idx in top_corr.index])
plt.xlabel('Absolute Correlation')
plt.title('Top 10 Variable Correlations', fontsize=14, fontweight='bold')
plt.gca().invert_yaxis()

# 3. Pairwise scatter plots for highly correlated variables
plt.subplot(2, 2, 3)
# Find variables with correlation > 0.5 (excluding self-correlation)
high_corr_pairs = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i+1, len(correlation_matrix.columns)):
        corr_val = correlation_matrix.iloc[i, j]
        if abs(corr_val) > 0.5:
            high_corr_pairs.append((correlation_matrix.columns[i], 
                                  correlation_matrix.columns[j], corr_val))

# Sort by absolute correlation
high_corr_pairs.sort(key=lambda x: abs(x[2]), reverse=True)

if high_corr_pairs:
    # Plot the most correlated pair
    var1, var2, corr_val = high_corr_pairs[0]
    plt.scatter(data[var1], data[var2], alpha=0.6, s=20)
    plt.xlabel(var1)
    plt.ylabel(var2)
    plt.title(f'Most Correlated Pair\n{var1} vs {var2}\n(r = {corr_val:.3f})', 
              fontsize=12, fontweight='bold')
    
    # Add trend line
    z = np.polyfit(data[var1], data[var2], 1)
    p = np.poly1d(z)
    plt.plot(data[var1], p(data[var1]), "r--", alpha=0.8)
else:
    plt.text(0.5, 0.5, 'No high correlations\nfound (>0.5)', 
             ha='center', va='center', transform=plt.gca().transAxes)
    plt.title('High Correlation Scatter Plot', fontsize=12, fontweight='bold')

# 4. Distribution of correlation coefficients
plt.subplot(2, 2, 4)
# Get all correlation values (excluding diagonal)
corr_values = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i+1, len(correlation_matrix.columns)):
        corr_values.append(correlation_matrix.iloc[i, j])

plt.hist(corr_values, bins=20, alpha=0.7, edgecolor='black')
plt.xlabel('Correlation Coefficient')
plt.ylabel('Frequency')
plt.title('Distribution of Correlation Coefficients', fontsize=12, fontweight='bold')
plt.axvline(x=0, color='red', linestyle='--', alpha=0.7, label='No correlation')
plt.legend()

plt.tight_layout()
plt.savefig(os.path.join(outputfolder, 'correlation_analysis.png'), dpi=300, bbox_inches='tight')
plt.show()

# Create detailed correlation report
print("\n" + "="*50)
print("DETAILED CORRELATION ANALYSIS")
print("="*50)

# Print correlation matrix
print("\nCorrelation Matrix:")
print(correlation_matrix.round(3))

# Find and print highly correlated pairs
print(f"\nHighly Correlated Variable Pairs (|r| > 0.5):")
if high_corr_pairs:
    for var1, var2, corr_val in high_corr_pairs:
        print(f"  {var1} vs {var2}: r = {corr_val:.3f}")
else:
    print("  No highly correlated pairs found (|r| > 0.5)")

# Statistical significance test
print(f"\nCorrelation Significance Test (p < 0.05):")
significant_pairs = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i+1, len(correlation_matrix.columns)):
        var1 = correlation_matrix.columns[i]
        var2 = correlation_matrix.columns[j]
        corr_val = correlation_matrix.iloc[i, j]
        
        # Calculate p-value using scipy
        r, p_value = stats.pearsonr(data[var1], data[var2])
        
        if p_value < 0.05:
            significant_pairs.append((var1, var2, corr_val, p_value))

if significant_pairs:
    for var1, var2, corr_val, p_val in significant_pairs:
        print(f"  {var1} vs {var2}: r = {corr_val:.3f}, p = {p_val:.6f}")
else:
    print("  No statistically significant correlations found")

# Save correlation matrix to CSV
correlation_matrix.to_csv(os.path.join(outputfolder, 'correlation_matrix.csv'))

print(f"\nAnalysis complete!")
print(f"Files saved:")
print(f"  - correlation_analysis.png: Visualization plots")
print(f"  - correlation_matrix.csv: Correlation matrix data") 