"""
Multi-Output Neural Network Analysis

This script loads the trained multi-output neural network model and performs various analyses:
1. When temperature=20, SOC=50, how outputs change with varying charging power
2. When temperature=20, charging power=10, how outputs change with varying SOC
3. How outputs change with varying temperature
"""

import torch
from torch import Tensor
import torch.nn as nn
import torch.nn.functional as F
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import pickle
from sklearn.preprocessing import StandardScaler

# Import the model class from the training script
class MultiOutputNet(nn.Module):
    """
    改进的多输出神经网络 - 温度替换架构
    根据领域知识设计：
    - 电池温度预测：基于原始输入 [SOC, ChargingPower, AmbientTemp]
    - 效率预测：使用预测的电池温度替换环境温度 [SOC, ChargingPower, PredictedBatteryTemp]
    
    关键创新：效率预测使用预测的电池温度而非环境温度，更符合物理规律
    """
    
    def __init__(self, input_size=3, shared_layer_sizes=None, temp_layer_sizes=None, eff_layer_sizes=None):
        super(MultiOutputNet, self).__init__()
        
        # 共享特征提取层
        shared_layers = []
        in_features = input_size
        for i, out_features in enumerate(shared_layer_sizes):
            shared_layers.append(nn.Linear(in_features, out_features))
            shared_layers.append(nn.ReLU())
            in_features = out_features
        
        self.shared_layers = nn.Sequential(*shared_layers)
        
        # 电池温度预测分支
        temp_layers = []
        temp_in_features = shared_layer_sizes[-1]  # 来自共享层的输出
        for i, out_features in enumerate(temp_layer_sizes):
            temp_layers.append(nn.Linear(temp_in_features, out_features))
            if i < len(temp_layer_sizes) - 1:  # 不是最后一层
                temp_layers.append(nn.ReLU())
            temp_in_features = out_features
        
        self.battery_temp_branch = nn.Sequential(*temp_layers)
        
        # 效率预测分支 (使用预测的电池温度替换环境温度)
        eff_layers = []
        eff_in_features = shared_layer_sizes[-1]  # 共享特征，不包含额外输入
        for i, out_features in enumerate(eff_layer_sizes):
            eff_layers.append(nn.Linear(eff_in_features, out_features))
            if i < len(eff_layer_sizes) - 1:  # 不是最后一层
                eff_layers.append(nn.ReLU())
            eff_in_features = out_features
        
        self.efficiency_branch = nn.Sequential(*eff_layers)
    
    def forward(self, x):
        # x: [SOC, ChargingPower_kW, AmbientTemp]
        # 使用温度分支的共享特征提取
        temp_shared_features = self.shared_layers(x)
        
        # 预测电池温度
        battery_temp = self.battery_temp_branch(temp_shared_features)
        
        # 创建用于效率预测的修改输入：用预测的电池温度替换环境温度
        # 原始输入: [SOC, ChargingPower, AmbientTemp]
        # 修改后: [SOC, ChargingPower, PredictedBatteryTemp]
        modified_input = torch.cat([x[:, :2], battery_temp], dim=1)  # 保留SOC和Power，用预测温度替换环境温度
        
        # 使用修改后的输入提取共享特征（使用相同的共享层）
        eff_shared_features = self.shared_layers(modified_input)
        
        # 预测效率
        efficiency = self.efficiency_branch(eff_shared_features)
        
        return battery_temp, efficiency

def load_model_and_scalers():
    """Load the trained model and scalers"""
    # Load scalers
    try:
        with open('scaler_multi_output_input.pkl', 'rb') as f:
            input_scaler = pickle.load(f)
        with open('scaler_multi_output_output.pkl', 'rb') as f:
            output_scaler = pickle.load(f)
        print("Loaded scalers from training")
    except FileNotFoundError:
        print("Error: Scaler files not found!")
        return None, None, None
    
    # Load model
    try:
        with open('Model_MultiOutput_charging.pkl', 'rb') as f:
            model_data = pickle.load(f)
        
        # Create model with the same architecture
        model_params = model_data['model_params']
        net = MultiOutputNet(**model_params)
        
        # Load model state dict
        if 'model_state_dict' in model_data:
            net.load_state_dict(model_data['model_state_dict'])
        else:
            net.load_state_dict(model_data)
        
        print("Model loaded successfully!")
    except FileNotFoundError:
        print("Error: Model file not found!")
        return None, None, None
    except Exception as e:
        print(f"Error loading model: {e}")
        return None, None, None
    
    return net, input_scaler, output_scaler

def analyze_charging_power_effect(net, input_scaler, output_scaler):
    """Analyze how outputs change with varying charging power when temperature=20, SOC=50"""
    print("Analyzing effect of charging power (temperature=20, SOC=50)...")
    
    # Create input data: temperature=20, SOC=50, charging power varies
    ambient_temp = 20
    soc = 50
    charging_powers = np.linspace(5, 20, 100)  # Charging power from 5 to 20 kW
    
    # Prepare inputs
    inputs = np.column_stack([
        np.full_like(charging_powers, soc),
        charging_powers,
        np.full_like(charging_powers, ambient_temp)
    ])
    
    # Scale inputs
    inputs_scaled = input_scaler.transform(inputs)
    inputs_tensor = torch.from_numpy(inputs_scaled).float()
    
    # Get predictions
    net.eval()
    with torch.no_grad():
        battery_temp_pred, efficiency_pred = net(inputs_tensor)
    
    # Scale outputs back
    outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
    outputs_unscaled = output_scaler.inverse_transform(outputs)
    
    # Plot results
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    
    # Battery temperature vs charging power
    axes[0].plot(charging_powers, outputs_unscaled[:, 0], 'b-', linewidth=2)
    axes[0].set_xlabel('Charging Power (kW)')
    axes[0].set_ylabel('Battery Temperature (°C)')
    axes[0].set_title('Battery Temperature vs Charging Power (Temp=20°C, SOC=50%)')
    axes[0].grid(True)
    
    # Efficiency vs charging power
    axes[1].plot(charging_powers, outputs_unscaled[:, 1], 'r-', linewidth=2)
    axes[1].set_xlabel('Charging Power (kW)')
    axes[1].set_ylabel('Charging Efficiency')
    axes[1].set_title('Charging Efficiency vs Charging Power (Temp=20°C, SOC=50%)')
    axes[1].grid(True)
    
    plt.tight_layout()
    plt.savefig('05_multi_output_charging_power_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Charging power analysis saved to '05_multi_output_charging_power_analysis.png'")

def analyze_soc_effect(net, input_scaler, output_scaler):
    """Analyze how outputs change with varying SOC when temperature=20, charging power=10"""
    print("Analyzing effect of SOC (temperature=20, charging power=10)...")
    
    # Create input data: temperature=20, charging power=10, SOC varies
    ambient_temp = 20
    charging_power = 10
    socs = np.linspace(10, 90, 100)  # SOC from 10% to 90%
    
    # Prepare inputs
    inputs = np.column_stack([
        socs,
        np.full_like(socs, charging_power),
        np.full_like(socs, ambient_temp)
    ])
    
    # Scale inputs
    inputs_scaled = input_scaler.transform(inputs)
    inputs_tensor = torch.from_numpy(inputs_scaled).float()
    
    # Get predictions
    net.eval()
    with torch.no_grad():
        battery_temp_pred, efficiency_pred = net(inputs_tensor)
    
    # Scale outputs back
    outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
    outputs_unscaled = output_scaler.inverse_transform(outputs)
    
    # Plot results
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    
    # Battery temperature vs SOC
    axes[0].plot(socs, outputs_unscaled[:, 0], 'b-', linewidth=2)
    axes[0].set_xlabel('SOC (%)')
    axes[0].set_ylabel('Battery Temperature (°C)')
    axes[0].set_title('Battery Temperature vs SOC (Temp=20°C, Power=10kW)')
    axes[0].grid(True)
    
    # Efficiency vs SOC
    axes[1].plot(socs, outputs_unscaled[:, 1], 'r-', linewidth=2)
    axes[1].set_xlabel('SOC (%)')
    axes[1].set_ylabel('Charging Efficiency')
    axes[1].set_title('Charging Efficiency vs SOC (Temp=20°C, Power=10kW)')
    axes[1].grid(True)
    
    plt.tight_layout()
    plt.savefig('05_multi_output_soc_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("SOC analysis saved to '05_multi_output_soc_analysis.png'")

def analyze_temperature_effect(net, input_scaler, output_scaler):
    """Analyze how outputs change with varying temperature when SOC=50, charging power=10"""
    print("Analyzing effect of ambient temperature (SOC=50, charging power=10)...")
    
    # Create input data: SOC=50, charging power=10, temperature varies
    soc = 50
    charging_power = 10
    temperatures = np.linspace(0, 40, 100)  # Temperature from 0°C to 40°C
    
    # Prepare inputs
    inputs = np.column_stack([
        np.full_like(temperatures, soc),
        np.full_like(temperatures, charging_power),
        temperatures
    ])
    
    # Scale inputs
    inputs_scaled = input_scaler.transform(inputs)
    inputs_tensor = torch.from_numpy(inputs_scaled).float()
    
    # Get predictions
    net.eval()
    with torch.no_grad():
        battery_temp_pred, efficiency_pred = net(inputs_tensor)
    
    # Scale outputs back
    outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
    outputs_unscaled = output_scaler.inverse_transform(outputs)
    
    # Plot results
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    
    # Battery temperature vs ambient temperature
    axes[0].plot(temperatures, outputs_unscaled[:, 0], 'b-', linewidth=2)
    axes[0].set_xlabel('Ambient Temperature (°C)')
    axes[0].set_ylabel('Battery Temperature (°C)')
    axes[0].set_title('Battery Temperature vs Ambient Temperature (SOC=50%, Power=10kW)')
    axes[0].grid(True)
    
    # Efficiency vs ambient temperature
    axes[1].plot(temperatures, outputs_unscaled[:, 1], 'r-', linewidth=2)
    axes[1].set_xlabel('Ambient Temperature (°C)')
    axes[1].set_ylabel('Charging Efficiency')
    axes[1].set_title('Charging Efficiency vs Ambient Temperature (SOC=50%, Power=10kW)')
    axes[1].grid(True)
    
    plt.tight_layout()
    plt.savefig('05_multi_output_temperature_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Temperature analysis saved to '05_multi_output_temperature_analysis.png'")

def main():
    # Set random seeds for reproducibility
    random.seed(999)
    np.random.seed(999)
    torch.manual_seed(999)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    
    # Select device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Load model and scalers
    net, input_scaler, output_scaler = load_model_and_scalers()
    if net is None:
        return
    
    # Move model to device
    net = net.to(device).float()
    
    # Perform analyses
    analyze_charging_power_effect(net, input_scaler, output_scaler)
    analyze_soc_effect(net, input_scaler, output_scaler)
    analyze_temperature_effect(net, input_scaler, output_scaler)
    
    print("All analyses completed successfully!")

if __name__ == "__main__":
    main()