# Import necessary packages
import torch
from torch import Tensor
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import random
import numpy as np
import json
import math
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import os
import pickle
from sklearn.preprocessing import StandardScaler

class MultiOutputNet(nn.Module):
    """
    多输出神经网络设计
    输出1: 电池温度 (受SOC, 充电功率, 环境温度影响)
    输出2: 效率 (受SOC, 充电功率, 电池温度影响)
    """
    
    def __init__(self, input_size=3, shared_layer_sizes=None, temp_layer_sizes=None, eff_layer_sizes=None):
        super(MultiOutputNet, self).__init__()
        
        # 共享特征提取层
        shared_layers = []
        in_features = input_size
        for i, out_features in enumerate(shared_layer_sizes):
            shared_layers.append(nn.Linear(in_features, out_features))
            shared_layers.append(nn.ReLU())
            in_features = out_features
        
        self.shared_layers = nn.Sequential(*shared_layers)
        
        # 电池温度预测分支
        temp_layers = []
        temp_in_features = shared_layer_sizes[-1]  # 来自共享层的输出
        for i, out_features in enumerate(temp_layer_sizes):
            temp_layers.append(nn.Linear(temp_in_features, out_features))
            if i < len(temp_layer_sizes) - 1:  # 不是最后一层
                temp_layers.append(nn.ReLU())
            temp_in_features = out_features
        
        self.battery_temp_branch = nn.Sequential(*temp_layers)
        
        # 效率预测分支 (包含电池温度作为输入)
        eff_layers = []
        eff_in_features = shared_layer_sizes[-1] + 1  # 共享特征 + 电池温度
        for i, out_features in enumerate(eff_layer_sizes):
            eff_layers.append(nn.Linear(eff_in_features, out_features))
            if i < len(eff_layer_sizes) - 1:  # 不是最后一层
                eff_layers.append(nn.ReLU())
            eff_in_features = out_features
        
        self.efficiency_branch = nn.Sequential(*eff_layers)
    
    def forward(self, x):
        # x: [SOC, ChargingPower_kW, AmbientTemp]
        shared_features = self.shared_layers(x)
        
        # 预测电池温度
        battery_temp = self.battery_temp_branch(shared_features)
        
        # 将电池温度与共享特征连接，预测效率
        efficiency_input = torch.cat([shared_features, battery_temp], dim=1)
        efficiency = self.efficiency_branch(efficiency_input)
        
        return battery_temp, efficiency

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def get_dataset():
    # Load data from Standard_data_unique.csv (raw data)
    data_path = os.path.join('OutputData', 'Standard_data_unique.csv')
    DATA = pd.read_csv(data_path)
    
    # Extract input features: SOC, ChargingPower_kW, AmbientTemp
    soc = DATA.loc[:, 'SOC'].values.reshape(-1, 1)
    charging_power = DATA.loc[:, 'ChargingPower_kW'].values.reshape(-1, 1)
    ambient_temp = DATA.loc[:, 'AmbientTemp'].values.reshape(-1, 1)
    
    # Extract outputs: BatteryTemp, ChargingEfficiency
    battery_temp = DATA.loc[:, 'BatteryTemp'].values.reshape(-1, 1)
    eff = DATA.loc[:, 'ChargingEfficiency'].values.reshape(-1, 1)

    # Prepare input and output tensors
    temp_input = np.concatenate((soc, charging_power, ambient_temp), axis=1)
    temp_output = np.concatenate((battery_temp, eff), axis=1)
    
    # Create and fit scalers
    input_scaler = StandardScaler()
    output_scaler = StandardScaler()
    
    # Fit and transform the data
    temp_input_scaled = input_scaler.fit_transform(temp_input)
    temp_output_scaled = output_scaler.fit_transform(temp_output)
    
    in_tensors = torch.from_numpy(temp_input_scaled).float()
    out_tensors = torch.from_numpy(temp_output_scaled).float()

    # Save dataset for future use
    np.save("dataset.multi_output.in.npy", in_tensors.numpy())
    np.save("dataset.multi_output.out.npy", out_tensors.numpy())

    return torch.utils.data.TensorDataset(in_tensors, out_tensors), input_scaler, output_scaler

def custom_loss_function(y1_pred, y1_true, y2_pred, y2_true, alpha=0.5):
    """
    自定义损失函数
    alpha: 控制两个输出损失之间的权重
    """
    # 电池温度损失
    temp_loss = F.mse_loss(y1_pred, y1_true)
    
    # 效率损失
    efficiency_loss = F.mse_loss(y2_pred, y2_true)
    
    # 添加效率预测的变化性损失（鼓励预测值有更多变化）
    # 计算预测值和真实值的方差差异
    efficiency_variance_diff = torch.abs(torch.var(y2_pred) - torch.var(y2_true))
    
    # 添加预测值和真实值之间的相关性损失
    y2_pred_mean = torch.mean(y2_pred)
    y2_true_mean = torch.mean(y2_true)
    covariance = torch.mean((y2_pred - y2_pred_mean) * (y2_true - y2_true_mean))
    y2_pred_std = torch.std(y2_pred)
    y2_true_std = torch.std(y2_true)
    
    # 防止除零错误
    epsilon = 1e-8
    correlation = covariance / (y2_pred_std * y2_true_std + epsilon)
    correlation_loss = 1 - correlation  # 相关性越接近1，损失越小
    
    # 总损失
    total_loss = alpha * temp_loss + (1 - alpha) * efficiency_loss + 0.1 * efficiency_variance_diff + 0.1 * correlation_loss
    
    return total_loss, temp_loss, efficiency_loss

# Config the model training
def main():
    # Set random seeds for reproducibility
    random.seed(999)
    np.random.seed(999)
    torch.manual_seed(999)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # Hyperparameters (optimized by Optuna)
    NUM_EPOCH = 1000
    BATCH_SIZE = 64
    DECAY_EPOCH = 100
    DECAY_RATIO = 0.8
    LR_INI = 0.007546016121680901  # Optimized learning rate from Optuna
    ALPHA = 0.3  # 降低温度预测权重，增加效率预测权重
    
    # Optimized network architecture
    SHARED_LAYER_SIZES = [93, 91]  # Optimized shared layers (3 layers)
    TEMP_LAYER_SIZES = [126, 1]  # Optimized temp branch (1 layer)
    EFF_LAYER_SIZES = [105, 50, 1]  # 增加一层隐藏层以提高效率预测能力

    # Select GPU as default device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Load and transform dataset
    dataset, input_scaler, output_scaler = get_dataset()

    # Split the dataset with fixed random seed
    train_size = int(0.8 * len(dataset))
    valid_size = int(0.1 * len(dataset))
    test_size = len(dataset) - train_size - valid_size
    train_dataset, valid_dataset, test_dataset = torch.utils.data.random_split(
        dataset, [train_size, valid_size, test_size], 
        generator=torch.Generator().manual_seed(999)
    )
    

    kwargs = {'num_workers': 0, 'pin_memory': True}
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, **kwargs)
    valid_loader = torch.utils.data.DataLoader(valid_dataset, batch_size=BATCH_SIZE, shuffle=True, **kwargs)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, **kwargs)

    # Setup network with optimized architecture
    net = MultiOutputNet(
        input_size=3, 
        shared_layer_sizes=SHARED_LAYER_SIZES,
        temp_layer_sizes=TEMP_LAYER_SIZES,
        eff_layer_sizes=EFF_LAYER_SIZES
    ).to(device).float()

    # Log the number of parameters
    print("Number of parameters: ", count_parameters(net))
    print("Network architecture:")
    print(f"  Shared layers: {SHARED_LAYER_SIZES}")
    print(f"  Temp branch: {TEMP_LAYER_SIZES}")
    print(f"  Efficiency branch: {EFF_LAYER_SIZES}")

    # Setup optimizer with optimized parameters
    optimizer = optim.Adam(net.parameters(), lr=LR_INI) 

    # Define lists to store losses
    train_loss_list = np.zeros([NUM_EPOCH, 3])  # [total_loss, temp_loss, efficiency_loss]
    valid_loss_list = np.zeros([NUM_EPOCH, 3])
    
    # Early stopping parameters
    patience = 50
    best_valid_loss = float('inf')
    patience_counter = 0

    # Train the network
    for epoch_i in range(NUM_EPOCH):
        # Train for one epoch
        epoch_train_total_loss = 0
        epoch_train_temp_loss = 0
        epoch_train_efficiency_loss = 0

        net.train()
        optimizer.param_groups[0]['lr'] = LR_INI * (DECAY_RATIO ** (epoch_i // DECAY_EPOCH))
        
        for inputs, labels in train_loader:
            optimizer.zero_grad()
            inputs, labels = inputs.to(device).float(), labels.to(device).float()
            
            # Forward pass
            battery_temp_pred, efficiency_pred = net(inputs)
            
            # Split labels
            battery_temp_true = labels[:, 0:1]
            efficiency_true = labels[:, 1:2]
            
            # Calculate loss
            total_loss, temp_loss, efficiency_loss = custom_loss_function(
                battery_temp_pred, battery_temp_true, 
                efficiency_pred, efficiency_true, 
                alpha=ALPHA
            )
            
            total_loss.backward()
            optimizer.step()

            epoch_train_total_loss += total_loss.item()
            epoch_train_temp_loss += temp_loss.item()
            epoch_train_efficiency_loss += efficiency_loss.item()

        # Compute Validation Loss
        with torch.no_grad():
            epoch_valid_total_loss = 0
            epoch_valid_temp_loss = 0
            epoch_valid_efficiency_loss = 0

            for inputs, labels in valid_loader:
                inputs, labels = inputs.to(device).float(), labels.to(device).float()
                battery_temp_pred, efficiency_pred = net(inputs)
                
                battery_temp_true = labels[:, 0:1]
                efficiency_true = labels[:, 1:2]
                
                total_loss, temp_loss, efficiency_loss = custom_loss_function(
                    battery_temp_pred, battery_temp_true, 
                    efficiency_pred, efficiency_true, 
                    alpha=ALPHA
                )

                epoch_valid_total_loss += total_loss.item()
                epoch_valid_temp_loss += temp_loss.item()
                epoch_valid_efficiency_loss += efficiency_loss.item()
        
        # Calculate average losses
        train_count = len(train_loader)
        valid_count = len(valid_loader)
        train_loss_list[epoch_i, 0] = epoch_train_total_loss / train_count
        train_loss_list[epoch_i, 1] = epoch_train_temp_loss / train_count
        train_loss_list[epoch_i, 2] = epoch_train_efficiency_loss / train_count
        valid_loss_list[epoch_i, 0] = epoch_valid_total_loss / valid_count
        valid_loss_list[epoch_i, 1] = epoch_valid_temp_loss / valid_count
        valid_loss_list[epoch_i, 2] = epoch_valid_efficiency_loss / valid_count
        
        # Early stopping check
        if valid_loss_list[epoch_i, 0] < best_valid_loss:
            best_valid_loss = valid_loss_list[epoch_i, 0]
            patience_counter = 0
            # Save best model
            torch.save(net.state_dict(), "Model_MultiOutput_charging_best.sd")
        else:
            patience_counter += 1
            
        if patience_counter >= patience:
            print(f"Early stopping at epoch {epoch_i+1}")
            break

        if (epoch_i+1) % 100 == 0:
            print(f"Epoch [{epoch_i+1}/{NUM_EPOCH}], Train Loss: {train_loss_list[epoch_i, 0]:.6f}, Valid Loss: {valid_loss_list[epoch_i, 0]:.6f}")
            print(f"  Temp Train Loss: {train_loss_list[epoch_i, 1]:.6f}, Temp Valid Loss: {valid_loss_list[epoch_i, 1]:.6f}")
            print(f"  Eff Train Loss: {train_loss_list[epoch_i, 2]:.6f}, Eff Valid Loss: {valid_loss_list[epoch_i, 2]:.6f}")
    
    # Load best model for final evaluation
    try:
        net.load_state_dict(torch.load("Model_MultiOutput_charging_best.sd"))
        print("Loaded best model for final evaluation")
    except FileNotFoundError:
        print("Best model not found, using final model for evaluation")
    
    # Save the model parameters
    torch.save(net.state_dict(), "Model_MultiOutput_charging.sd")
    print("Training finished! Model is saved!")
    
    # Save model and scalers as pkl files
    model_data = {
        'model_state_dict': net.state_dict(),
        'model_class': MultiOutputNet,
        'model_params': {
            'input_size': 3, 
            'shared_layer_sizes': SHARED_LAYER_SIZES,
            'temp_layer_sizes': TEMP_LAYER_SIZES,
            'eff_layer_sizes': EFF_LAYER_SIZES
        }
    }
    
    with open('Model_MultiOutput_charging.pkl', 'wb') as f:
        pickle.dump(model_data, f)
    
    with open('scaler_multi_output_input.pkl', 'wb') as f:
        pickle.dump(input_scaler, f)
    
    with open('scaler_multi_output_output.pkl', 'wb') as f:
        pickle.dump(output_scaler, f)
    
    print("Model and scalers saved as pkl files!")
    
    np.savetxt('train_loss_multi_output.csv', train_loss_list, delimiter=',')
    np.savetxt('valid_loss_multi_output.csv', valid_loss_list, delimiter=',')

    # Evaluation
    net.eval()
    inputs_list = []
    y_meas = []
    y_pred = []

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device).float(), labels.to(device).float()
            battery_temp_pred, efficiency_pred = net(inputs)
            outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1)
            
            y_pred.append(outputs)
            y_meas.append(labels.to(device))
            inputs_list.append(inputs.to(device))

    # Concatenate all batches for full dataset predictions
    inputs_array = torch.cat(inputs_list, dim=0)
    y_meas = torch.cat(y_meas, dim=0)
    y_pred = torch.cat(y_pred, dim=0)
    
    print(f"Test shapes - y_meas: {y_meas.shape}, y_pred: {y_pred.shape}")
    
    # Calculate overall metrics
    mse_value = F.mse_loss(y_meas, y_pred).item()
    rmse_value = np.sqrt(mse_value)
    mae_value = F.l1_loss(y_meas, y_pred).item()
    print(f"Test MSE: {mse_value:.10f}")
    print(f"Test RMSE: {rmse_value:.10f}")
    print(f"Test MAE: {mae_value:.10f}")

    # Convert tensors to numpy arrays for further processing
    inputs_array = inputs_array.cpu().numpy()
    y_meas = y_meas.cpu().numpy()
    y_pred = y_pred.cpu().numpy()

    # Create DataFrame to save results
    df = pd.DataFrame(inputs_array, columns=[f'input_{i}' for i in range(inputs_array.shape[1])])
    output_data = {
        'y_meas_battery_temp': y_meas[:, 0], 'y_pred_battery_temp': y_pred[:, 0],
        'y_meas_efficiency': y_meas[:, 1], 'y_pred_efficiency': y_pred[:, 1]
    }
    df = pd.concat([df, pd.DataFrame(output_data)], axis=1)

    epsilon = 1e-8
    metrics = {'MAE': [], 'MSE': [], 'RMSE': [], 'MAPE': [], 'R2': []}

    # Calculate errors for each output
    output_names = ['battery_temp', 'efficiency']
    for i in range(2):
        mae = np.abs(y_meas[:, i] - y_pred[:, i])
        mse = (y_meas[:, i] - y_pred[:, i]) ** 2
        rmse = np.sqrt(mse)
        mape = np.abs((y_meas[:, i] - y_pred[:, i]) / (y_meas[:, i] + epsilon)) * 100
        r2 = r2_score(y_meas[:, i], y_pred[:, i])

        # Store each metric in the DataFrame
        df[f'MAE_{output_names[i]}'] = mae
        df[f'MSE_{output_names[i]}'] = mse
        df[f'RMSE_{output_names[i]}'] = rmse
        df[f'MAPE_{output_names[i]}'] = mape
        df[f'R2_{output_names[i]}'] = r2

        # Collect mean values
        metrics['MAE'].append(np.mean(mae))
        metrics['MSE'].append(np.mean(mse))
        metrics['RMSE'].append(np.mean(rmse))
        metrics['MAPE'].append(np.mean(mape))
        metrics['R2'].append(r2)

    # Print mean of each metric for all outputs
    for metric, values in metrics.items():
        print(f"Mean {metric}: {np.mean(values):.10f}")
    
    # 添加额外的分析信息
    print("\nDetailed Analysis:")
    print(f"  Battery Temp R² std: {np.std([r2_score(y_meas[i::len(y_meas)//2, 0], y_pred[i::len(y_pred)//2, 0]) for i in range(len(y_meas)//2)]):.6f}")
    print(f"  Efficiency R² std: {np.std([r2_score(y_meas[i::len(y_meas)//2, 1], y_pred[i::len(y_pred)//2, 1]) for i in range(len(y_meas)//2)]):.6f}")
    print(f"  Battery Temp variance - True: {np.var(y_meas[:, 0]):.6f}, Pred: {np.var(y_pred[:, 0]):.6f}")
    print(f"  Efficiency variance - True: {np.var(y_meas[:, 1]):.6f}, Pred: {np.var(y_pred[:, 1]):.6f}")

    # Save the DataFrame to a CSV file
    csv_file_path = 'full_data_y_meas_y_pred_multi_output.csv'
    df.to_csv(csv_file_path, index=False)
    print(f"Saved full data with measurements and predictions to '{csv_file_path}'")

    # Generate scatter plots for each output variable
    output_columns = ['y_meas_battery_temp', 'y_pred_battery_temp', 'y_meas_efficiency', 'y_pred_efficiency']
    colors = ['red', 'blue']
    titles = ['Battery Temperature', 'Charging Efficiency']

    for i in range(2):
        plt.figure(figsize=(8, 6))
        plt.scatter(df[f'y_meas_{output_names[i]}'], df[f'y_pred_{output_names[i]}'], 
                   color=colors[i], alpha=0.5)
        plt.title(f'Actual vs. Predicted Values for {titles[i]}\nR^2 Score: {metrics["R2"][i]:.4f}')
        plt.xlabel('Actual Values')
        plt.ylabel('Predicted Values')
        plt.grid(True)
        plt.axis('equal')
        # Use the actual min and max values from the data for the diagonal line
        min_val = min(df[f'y_meas_{output_names[i]}'].min(), df[f'y_pred_{output_names[i]}'].min())
        max_val = max(df[f'y_meas_{output_names[i]}'].max(), df[f'y_pred_{output_names[i]}'].max())
        plt.plot([min_val, max_val], [min_val, max_val], 'k--')
        plt.savefig(f'multi_output_scatter_plot_{output_names[i]}.png')
        plt.close()

    # --- Save validation set predictions/results to CSV ---
    val_inputs_list = []
    val_y_meas = []
    val_y_pred = []

    with torch.no_grad():
        for inputs, labels in valid_loader:
            inputs, labels = inputs.to(device).float(), labels.to(device).float()
            battery_temp_pred, efficiency_pred = net(inputs)
            outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1)
            
            val_y_pred.append(outputs)
            val_y_meas.append(labels.to(device))
            val_inputs_list.append(inputs.to(device))

    val_inputs_array = torch.cat(val_inputs_list, dim=0)
    val_y_meas = torch.cat(val_y_meas, dim=0)
    val_y_pred = torch.cat(val_y_pred, dim=0)

    # Reverse normalization
    val_inputs_array = val_inputs_array.cpu().numpy()
    val_y_meas = val_y_meas.cpu().numpy()
    val_y_pred = val_y_pred.cpu().numpy()

    val_inputs_array = input_scaler.inverse_transform(val_inputs_array)
    val_y_meas = output_scaler.inverse_transform(val_y_meas)
    val_y_pred = output_scaler.inverse_transform(val_y_pred)

    val_df = pd.DataFrame(val_inputs_array, columns=[f'input_{i}' for i in range(val_inputs_array.shape[1])])
    val_output_data = {
        'y_meas_battery_temp': val_y_meas[:, 0], 'y_pred_battery_temp': val_y_pred[:, 0],
        'y_meas_efficiency': val_y_meas[:, 1], 'y_pred_efficiency': val_y_pred[:, 1]
    }
    val_df = pd.concat([val_df, pd.DataFrame(val_output_data)], axis=1)
    val_csv_file_path = 'validation_data_y_meas_y_pred_multi_output.csv'
    val_df.to_csv(val_csv_file_path, index=False)
    print(f"Saved validation data with measurements and predictions to '{val_csv_file_path}'")

if __name__ == "__main__":
    main()