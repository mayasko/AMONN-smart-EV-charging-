"""
Test Results Analysis Script

This script analyzes the test dataset results from both improved attention and multi-output models.
It calculates MSE, MAPE, and R2 metrics for overall, temperature, and efficiency predictions.
"""

import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
import seaborn as sns

def calculate_metrics(y_true, y_pred):
    """
    Calculate MSE, MAPE, and R2 metrics
    
    Args:
        y_true: True values
        y_pred: Predicted values
    
    Returns:
        dict: Dictionary containing MSE, MAPE, and R2 values
    """
    # MSE
    mse = mean_squared_error(y_true, y_pred)
    
    # MAPE (Mean Absolute Percentage Error)
    mape = np.mean(np.abs((y_true - y_pred) / (y_true + 1e-8))) * 100
    
    # R2 Score
    r2 = r2_score(y_true, y_pred)
    
    return {
        'MSE': mse,
        'MAPE': mape,
        'R2': r2
    }

def analyze_model_results(csv_file_path, model_name):
    """
    Analyze results for a specific model
    
    Args:
        csv_file_path: Path to the CSV file with results
        model_name: Name of the model for display
    
    Returns:
        dict: Dictionary containing all metrics
    """
    print(f"\n{'='*60}")
    print(f"ANALYZING {model_name.upper()} MODEL RESULTS")
    print(f"{'='*60}")
    
    try:
        # Load the CSV file
        df = pd.read_csv(csv_file_path)
        print(f"Loaded data from: {csv_file_path}")
        print(f"Dataset shape: {df.shape}")
        
        # Extract true and predicted values
        y_true_temp = df['y_meas_battery_temp'].values
        y_pred_temp = df['y_pred_battery_temp'].values
        y_true_eff = df['y_meas_efficiency'].values
        y_pred_eff = df['y_pred_efficiency'].values
        
        # Combine for overall metrics
        y_true_overall = np.concatenate([y_true_temp, y_true_eff])
        y_pred_overall = np.concatenate([y_pred_temp, y_pred_eff])
        
        # Calculate metrics for each output
        temp_metrics = calculate_metrics(y_true_temp, y_pred_temp)
        eff_metrics = calculate_metrics(y_true_eff, y_pred_eff)
        overall_metrics = calculate_metrics(y_true_overall, y_pred_overall)
        
        # Display results
        print(f"\n{model_name} Model Results:")
        print("-" * 40)
        
        print("\nOVERALL METRICS (Temperature + Efficiency):")
        print(f"  MSE:  {overall_metrics['MSE']:.6f}")
        print(f"  MAPE: {overall_metrics['MAPE']:.4f}%")
        print(f"  R²:   {overall_metrics['R2']:.6f}")
        
        print("\nTEMPERATURE PREDICTION METRICS:")
        print(f"  MSE:  {temp_metrics['MSE']:.6f}")
        print(f"  MAPE: {temp_metrics['MAPE']:.4f}%")
        print(f"  R²:   {temp_metrics['R2']:.6f}")
        
        print("\nEFFICIENCY PREDICTION METRICS:")
        print(f"  MSE:  {eff_metrics['MSE']:.6f}")
        print(f"  MAPE: {eff_metrics['MAPE']:.4f}%")
        print(f"  R²:   {eff_metrics['R2']:.6f}")
        
        # Additional statistics
        print(f"\nADDITIONAL STATISTICS:")
        print(f"  Temperature - True mean: {np.mean(y_true_temp):.4f}, Pred mean: {np.mean(y_pred_temp):.4f}")
        print(f"  Temperature - True std:  {np.std(y_true_temp):.4f}, Pred std:  {np.std(y_pred_temp):.4f}")
        print(f"  Efficiency - True mean:  {np.mean(y_true_eff):.4f}, Pred mean: {np.mean(y_pred_eff):.4f}")
        print(f"  Efficiency - True std:   {np.std(y_true_eff):.4f}, Pred std:  {np.std(y_pred_eff):.4f}")
        
        return {
            'overall': overall_metrics,
            'temperature': temp_metrics,
            'efficiency': eff_metrics,
            'data': {
                'y_true_temp': y_true_temp,
                'y_pred_temp': y_pred_temp,
                'y_true_eff': y_true_eff,
                'y_pred_eff': y_pred_eff
            }
        }
        
    except FileNotFoundError:
        print(f"Error: File {csv_file_path} not found!")
        return None
    except Exception as e:
        print(f"Error analyzing {model_name}: {e}")
        return None

def compare_models(improved_attention_results, multi_output_results):
    """
    Compare results between the two models
    
    Args:
        improved_attention_results: Results from improved attention model
        multi_output_results: Results from multi-output model
    """
    print(f"\n{'='*60}")
    print("MODEL COMPARISON")
    print(f"{'='*60}")
    
    if improved_attention_results is None or multi_output_results is None:
        print("Cannot compare models - missing results")
        return
    
    # Create comparison table
    comparison_data = []
    
    for metric_type in ['overall', 'temperature', 'efficiency']:
        for metric in ['MSE', 'MAPE', 'R2']:
            improved_val = improved_attention_results[metric_type][metric]
            multi_val = multi_output_results[metric_type][metric]
            
            # Determine which is better
            if metric == 'R2':
                better_model = "Improved Attention" if improved_val > multi_val else "Multi-Output"
                improvement = ((improved_val - multi_val) / multi_val) * 100 if multi_val != 0 else 0
            else:  # MSE and MAPE (lower is better)
                better_model = "Improved Attention" if improved_val < multi_val else "Multi-Output"
                improvement = ((multi_val - improved_val) / multi_val) * 100 if multi_val != 0 else 0
            
            comparison_data.append({
                'Metric Type': metric_type.title(),
                'Metric': metric,
                'Improved Attention': improved_val,
                'Multi-Output': multi_val,
                'Better Model': better_model,
                'Improvement %': improvement
            })
    
    # Display comparison table
    comparison_df = pd.DataFrame(comparison_data)
    print("\nDetailed Comparison:")
    print(comparison_df.to_string(index=False, float_format='%.6f'))
    
    # Summary statistics
    print(f"\nSUMMARY:")
    improved_better_count = len([row for row in comparison_data if row['Better Model'] == 'Improved Attention'])
    total_metrics = len(comparison_data)
    print(f"Improved Attention performs better in {improved_better_count}/{total_metrics} metrics")
    
    return comparison_df

def create_visualization(improved_attention_results, multi_output_results):
    """
    Create visualization of the results
    
    Args:
        improved_attention_results: Results from improved attention model
        multi_output_results: Results from multi-output model
    """
    if improved_attention_results is None or multi_output_results is None:
        print("Cannot create visualization - missing results")
        return
    
    # Prepare data for plotting
    metrics = ['MSE', 'MAPE', 'R2']
    model_types = ['Temperature', 'Efficiency']
    
    # Create subplots
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    for i, metric in enumerate(metrics):
        improved_temp = improved_attention_results['temperature'][metric]
        improved_eff = improved_attention_results['efficiency'][metric]
        multi_temp = multi_output_results['temperature'][metric]
        multi_eff = multi_output_results['efficiency'][metric]
        
        x = np.arange(len(model_types))
        width = 0.35
        
        axes[i].bar(x - width/2, [improved_temp, improved_eff], width, 
                   label='Improved Attention', alpha=0.8)
        axes[i].bar(x + width/2, [multi_temp, multi_eff], width, 
                   label='Multi-Output', alpha=0.8)
        
        axes[i].set_xlabel('Output Type')
        axes[i].set_ylabel(metric)
        axes[i].set_title(f'{metric} Comparison')
        axes[i].set_xticks(x)
        axes[i].set_xticklabels(model_types)
        axes[i].legend()
        axes[i].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('model_comparison_metrics.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("\nVisualization saved as 'model_comparison_metrics.png'")
    
    # Create scatter plots for predictions vs actual
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # Temperature predictions
    axes[0, 0].scatter(improved_attention_results['data']['y_true_temp'], 
                       improved_attention_results['data']['y_pred_temp'], 
                       alpha=0.6, label='Improved Attention')
    axes[0, 0].scatter(multi_output_results['data']['y_true_temp'], 
                       multi_output_results['data']['y_pred_temp'], 
                       alpha=0.6, label='Multi-Output')
    axes[0, 0].plot([improved_attention_results['data']['y_true_temp'].min(), 
                     improved_attention_results['data']['y_true_temp'].max()], 
                    [improved_attention_results['data']['y_true_temp'].min(), 
                     improved_attention_results['data']['y_true_temp'].max()], 
                    'k--', alpha=0.5)
    axes[0, 0].set_xlabel('Actual Temperature (°C)')
    axes[0, 0].set_ylabel('Predicted Temperature (°C)')
    axes[0, 0].set_title('Temperature Predictions')
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    # Efficiency predictions
    axes[0, 1].scatter(improved_attention_results['data']['y_true_eff'], 
                       improved_attention_results['data']['y_pred_eff'], 
                       alpha=0.6, label='Improved Attention')
    axes[0, 1].scatter(multi_output_results['data']['y_true_eff'], 
                       multi_output_results['data']['y_pred_eff'], 
                       alpha=0.6, label='Multi-Output')
    axes[0, 1].plot([improved_attention_results['data']['y_true_eff'].min(), 
                     improved_attention_results['data']['y_true_eff'].max()], 
                    [improved_attention_results['data']['y_true_eff'].min(), 
                     improved_attention_results['data']['y_true_eff'].max()], 
                    'k--', alpha=0.5)
    axes[0, 1].set_xlabel('Actual Efficiency')
    axes[0, 1].set_ylabel('Predicted Efficiency')
    axes[0, 1].set_title('Efficiency Predictions')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    # Residual plots for temperature
    temp_residuals_improved = improved_attention_results['data']['y_true_temp'] - improved_attention_results['data']['y_pred_temp']
    temp_residuals_multi = multi_output_results['data']['y_true_temp'] - multi_output_results['data']['y_pred_temp']
    
    axes[1, 0].scatter(improved_attention_results['data']['y_pred_temp'], temp_residuals_improved, 
                       alpha=0.6, label='Improved Attention')
    axes[1, 0].scatter(multi_output_results['data']['y_pred_temp'], temp_residuals_multi, 
                       alpha=0.6, label='Multi-Output')
    axes[1, 0].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    axes[1, 0].set_xlabel('Predicted Temperature (°C)')
    axes[1, 0].set_ylabel('Residuals')
    axes[1, 0].set_title('Temperature Residuals')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    # Residual plots for efficiency
    eff_residuals_improved = improved_attention_results['data']['y_true_eff'] - improved_attention_results['data']['y_pred_eff']
    eff_residuals_multi = multi_output_results['data']['y_true_eff'] - multi_output_results['data']['y_pred_eff']
    
    axes[1, 1].scatter(improved_attention_results['data']['y_pred_eff'], eff_residuals_improved, 
                       alpha=0.6, label='Improved Attention')
    axes[1, 1].scatter(multi_output_results['data']['y_pred_eff'], eff_residuals_multi, 
                       alpha=0.6, label='Multi-Output')
    axes[1, 1].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    axes[1, 1].set_xlabel('Predicted Efficiency')
    axes[1, 1].set_ylabel('Residuals')
    axes[1, 1].set_title('Efficiency Residuals')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('model_predictions_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Prediction analysis saved as 'model_predictions_analysis.png'")

def main():
    """
    Main function to run the analysis
    """
    print("TEST RESULTS ANALYSIS")
    print("=" * 60)
    
    # Analyze Improved Attention model results
    improved_attention_results = analyze_model_results(
        'full_data_y_meas_y_pred_improved_attention.csv', 
        'Improved Attention'
    )
    
    # Analyze Multi-Output model results
    multi_output_results = analyze_model_results(
        'full_data_y_meas_y_pred_multi_output.csv', 
        'Multi-Output'
    )
    
    # Compare models
    comparison_df = compare_models(improved_attention_results, multi_output_results)
    
    # Create visualizations
    create_visualization(improved_attention_results, multi_output_results)
    
    # Save comparison results to CSV
    if comparison_df is not None:
        comparison_df.to_csv('model_comparison_results.csv', index=False)
        print("\nComparison results saved to 'model_comparison_results.csv'")
    
    print(f"\n{'='*60}")
    print("ANALYSIS COMPLETED")
    print(f"{'='*60}")

if __name__ == "__main__":
    main() 