import pandas as pd
import numpy as np
import os

def test_data_loading():
    """Test if the data loading works correctly"""
    
    # Test loading normalized_unique.csv
    data_path = os.path.join('OutputData', 'normalized_unique.csv')
    print(f"Loading data from: {data_path}")
    
    try:
        DATA = pd.read_csv(data_path)
        print(f"Data loaded successfully! Shape: {DATA.shape}")
        print(f"Columns: {DATA.columns.tolist()}")
        print("\nFirst 5 rows:")
        print(DATA.head())
        
        # Test extracting the features we need
        soc = DATA.loc[:, 'SOC'].values.reshape(-1, 1)
        charging_power = DATA.loc[:, 'ChargingPower_kW'].values.reshape(-1, 1)
        battery_temp = DATA.loc[:, 'BatteryTemp'].values.reshape(-1, 1)
        eff = DATA.loc[:, 'ChargingEfficiency'].values.reshape(-1, 1)
        
        print(f"\nFeature shapes:")
        print(f"SOC: {soc.shape}")
        print(f"ChargingPower_kW: {charging_power.shape}")
        print(f"BatteryTemp: {battery_temp.shape}")
        print(f"ChargingEfficiency: {eff.shape}")
        
        # Test concatenation
        temp_input = np.concatenate((soc, charging_power, battery_temp), axis=1)
        print(f"\nConcatenated input shape: {temp_input.shape}")
        
        print("\nData ranges:")
        print(f"SOC: {soc.min():.3f} to {soc.max():.3f}")
        print(f"ChargingPower_kW: {charging_power.min():.3f} to {charging_power.max():.3f}")
        print(f"BatteryTemp: {battery_temp.min():.3f} to {battery_temp.max():.3f}")
        print(f"ChargingEfficiency: {eff.min():.3f} to {eff.max():.3f}")
        
        print("\n✅ Data loading test passed!")
        
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        return False
    
    return True

if __name__ == "__main__":
    test_data_loading() 