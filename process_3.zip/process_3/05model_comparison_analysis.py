"""
Model Comparison Analysis

This script loads both trained models and performs comparative analyses:
1. When temperature=20, SOC=50, how outputs change with varying charging power
2. When temperature=20, charging power=10, how outputs change with varying SOC
3. How outputs change with varying temperature
"""

import torch
from torch import Tensor
import torch.nn as nn
import torch.nn.functional as F
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import pickle
from sklearn.preprocessing import StandardScaler

# Import the model classes
class ImprovedAttentionMultiOutputNet(nn.Module):
    """
    改进的注意力机制多输出网络 - 温度替换架构
    根据领域知识，为不同输出使用不同的注意力机制：
    - 电池温度预测：更关注环境温度
    - 效率预测：使用预测的电池温度替换环境温度，更关注充电功率
    
    关键创新：效率预测使用预测的电池温度而非环境温度，更符合物理规律
    """
    
    def __init__(self, input_size=3, attention_hidden_size=64, shared_layer_sizes=None, temp_layer_sizes=None, eff_layer_sizes=None):
        super(ImprovedAttentionMultiOutputNet, self).__init__()
        
        # 为电池温度预测设计的注意力层（更关注环境温度）
        self.temp_attention = nn.Sequential(
            nn.Linear(input_size, attention_hidden_size),
            nn.Tanh(),
            nn.Linear(attention_hidden_size, input_size),
            nn.Softmax(dim=1)
        )
        
        # 为效率预测设计的注意力层（更关注充电功率）
        self.eff_attention = nn.Sequential(
            nn.Linear(input_size, attention_hidden_size),
            nn.Tanh(),
            nn.Linear(attention_hidden_size, input_size),
            nn.Softmax(dim=1)
        )
        
        # 共享特征提取层
        shared_layers = []
        in_features = input_size
        for i, out_features in enumerate(shared_layer_sizes):
            shared_layers.append(nn.Linear(in_features, out_features))
            shared_layers.append(nn.ReLU())
            in_features = out_features
        
        self.shared_layers = nn.Sequential(*shared_layers)
        
        # 电池温度预测分支
        temp_layers = []
        temp_in_features = shared_layer_sizes[-1]  # 来自共享层的输出
        for i, out_features in enumerate(temp_layer_sizes):
            temp_layers.append(nn.Linear(temp_in_features, out_features))
            if i < len(temp_layer_sizes) - 1:  # 不是最后一层
                temp_layers.append(nn.ReLU())
            temp_in_features = out_features
        
        self.temp_branch = nn.Sequential(*temp_layers)
        
        # 效率预测分支 (使用预测的电池温度替换环境温度)
        eff_layers = []
        eff_in_features = shared_layer_sizes[-1]  # 共享特征，不包含额外输入
        for i, out_features in enumerate(eff_layer_sizes):
            eff_layers.append(nn.Linear(eff_in_features, out_features))
            if i < len(eff_layer_sizes) - 1:  # 不是最后一层
                eff_layers.append(nn.ReLU())
            eff_in_features = out_features
        
        self.efficiency_branch = nn.Sequential(*eff_layers)
    
    def forward(self, x):
        """
        前向传播函数 - 使用温度替换架构
        """
        temp_attention_weights = self.temp_attention(x)
        temp_attended_input = x * temp_attention_weights
        
        # 使用电池温度注意力权重提取共享特征
        temp_shared_features = self.shared_layers(temp_attended_input)
        
        # 预测电池温度
        battery_temp = self.temp_branch(temp_shared_features)
        
        # 创建用于效率预测的修改输入：用预测的电池温度替换环境温度
        # 原始输入: [SOC, ChargingPower, AmbientTemp]
        # 修改后: [SOC, ChargingPower, PredictedBatteryTemp]
        modified_input = torch.cat([x[:, :2], battery_temp], dim=1)  # 保留SOC和Power，用预测温度替换环境温度
        
        # 效率预测路径的注意力机制（基于修改后的输入）
        eff_attention_weights = self.eff_attention(modified_input)
        
        eff_attended_input = modified_input * eff_attention_weights
        
        # 使用效率注意力权重提取共享特征（使用相同的共享层）
        eff_shared_features = self.shared_layers(eff_attended_input)
        
        # 预测效率
        efficiency = self.efficiency_branch(eff_shared_features)
        
        return battery_temp, efficiency, temp_attention_weights, eff_attention_weights

class MultiOutputNet(nn.Module):
    """
    改进的多输出神经网络 - 温度替换架构
    根据领域知识设计：
    - 电池温度预测：基于原始输入 [SOC, ChargingPower, AmbientTemp]
    - 效率预测：使用预测的电池温度替换环境温度 [SOC, ChargingPower, PredictedBatteryTemp]
    
    关键创新：效率预测使用预测的电池温度而非环境温度，更符合物理规律
    """
    
    def __init__(self, input_size=3, shared_layer_sizes=None, temp_layer_sizes=None, eff_layer_sizes=None):
        super(MultiOutputNet, self).__init__()
        
        # 共享特征提取层
        shared_layers = []
        in_features = input_size
        for i, out_features in enumerate(shared_layer_sizes):
            shared_layers.append(nn.Linear(in_features, out_features))
            shared_layers.append(nn.ReLU())
            in_features = out_features
        
        self.shared_layers = nn.Sequential(*shared_layers)
        
        # 电池温度预测分支
        temp_layers = []
        temp_in_features = shared_layer_sizes[-1]  # 来自共享层的输出
        for i, out_features in enumerate(temp_layer_sizes):
            temp_layers.append(nn.Linear(temp_in_features, out_features))
            if i < len(temp_layer_sizes) - 1:  # 不是最后一层
                temp_layers.append(nn.ReLU())
            temp_in_features = out_features
        
        self.battery_temp_branch = nn.Sequential(*temp_layers)
        
        # 效率预测分支 (使用预测的电池温度替换环境温度)
        eff_layers = []
        eff_in_features = shared_layer_sizes[-1]  # 共享特征，不包含额外输入
        for i, out_features in enumerate(eff_layer_sizes):
            eff_layers.append(nn.Linear(eff_in_features, out_features))
            if i < len(eff_layer_sizes) - 1:  # 不是最后一层
                eff_layers.append(nn.ReLU())
            eff_in_features = out_features
        
        self.efficiency_branch = nn.Sequential(*eff_layers)
    
    def forward(self, x):
        # x: [SOC, ChargingPower_kW, AmbientTemp]
        # 使用温度分支的共享特征提取
        temp_shared_features = self.shared_layers(x)
        
        # 预测电池温度
        battery_temp = self.battery_temp_branch(temp_shared_features)
        
        # 创建用于效率预测的修改输入：用预测的电池温度替换环境温度
        # 原始输入: [SOC, ChargingPower, AmbientTemp]
        # 修改后: [SOC, ChargingPower, PredictedBatteryTemp]
        modified_input = torch.cat([x[:, :2], battery_temp], dim=1)  # 保留SOC和Power，用预测温度替换环境温度
        
        # 使用修改后的输入提取共享特征（使用相同的共享层）
        eff_shared_features = self.shared_layers(modified_input)
        
        # 预测效率
        efficiency = self.efficiency_branch(eff_shared_features)
        
        return battery_temp, efficiency

def load_models_and_scalers():
    """Load both trained models and their scalers"""
    models = {}
    scalers = {}
    
    # Load improved attention model and scalers
    try:
        with open('scaler_improved_attention_input.pkl', 'rb') as f:
            scalers['attention_input'] = pickle.load(f)
        with open('scaler_improved_attention_output.pkl', 'rb') as f:
            scalers['attention_output'] = pickle.load(f)
        
        with open('Model_Improved_Attention_charging.pkl', 'rb') as f:
            model_data = pickle.load(f)
        
        model_params = model_data['model_params']
        models['attention'] = ImprovedAttentionMultiOutputNet(**model_params)
        
        if 'model_state_dict' in model_data:
            models['attention'].load_state_dict(model_data['model_state_dict'])
        else:
            models['attention'].load_state_dict(model_data)
        
        print("Improved attention model loaded successfully!")
    except Exception as e:
        print(f"Error loading improved attention model: {e}")
        models['attention'] = None
    
    # Load multi-output model and scalers
    try:
        with open('scaler_multi_output_input.pkl', 'rb') as f:
            scalers['multi_output_input'] = pickle.load(f)
        with open('scaler_multi_output_output.pkl', 'rb') as f:
            scalers['multi_output_output'] = pickle.load(f)
        
        with open('Model_MultiOutput_charging.pkl', 'rb') as f:
            model_data = pickle.load(f)
        
        model_params = model_data['model_params']
        models['multi_output'] = MultiOutputNet(**model_params)
        
        if 'model_state_dict' in model_data:
            models['multi_output'].load_state_dict(model_data['model_state_dict'])
        else:
            models['multi_output'].load_state_dict(model_data)
        
        print("Multi-output model loaded successfully!")
    except Exception as e:
        print(f"Error loading multi-output model: {e}")
        models['multi_output'] = None
    
    return models, scalers

def compare_charging_power_effect(models, scalers):
    """Compare how outputs change with varying charging power when temperature=20, SOC=50"""
    print("Comparing effect of charging power (temperature=20, SOC=50)...")
    
    # Create input data: temperature=20, SOC=50, charging power varies
    ambient_temp = 20
    soc = 50
    charging_powers = np.linspace(5, 20, 100)  # Charging power from 5 to 20 kW
    
    # Prepare inputs
    inputs = np.column_stack([
        np.full_like(charging_powers, soc),
        charging_powers,
        np.full_like(charging_powers, ambient_temp)
    ])
    
    # Get predictions from both models
    predictions = {}
    
    # Attention model predictions
    if models['attention'] is not None:
        inputs_scaled = scalers['attention_input'].transform(inputs)
        inputs_tensor = torch.from_numpy(inputs_scaled).float()
        
        models['attention'].eval()
        with torch.no_grad():
            battery_temp_pred, efficiency_pred, _, _ = models['attention'](inputs_tensor)
        
        outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
        predictions['attention'] = scalers['attention_output'].inverse_transform(outputs)
    
    # Multi-output model predictions
    if models['multi_output'] is not None:
        inputs_scaled = scalers['multi_output_input'].transform(inputs)
        inputs_tensor = torch.from_numpy(inputs_scaled).float()
        
        models['multi_output'].eval()
        with torch.no_grad():
            battery_temp_pred, efficiency_pred = models['multi_output'](inputs_tensor)
        
        outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
        predictions['multi_output'] = scalers['multi_output_output'].inverse_transform(outputs)
    
    # Plot comparison results
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Battery temperature vs charging power
    axes[0, 0].plot(charging_powers, predictions['attention'][:, 0], 'b-', linewidth=2, label='Attention Model')
    if 'multi_output' in predictions:
        axes[0, 0].plot(charging_powers, predictions['multi_output'][:, 0], 'g--', linewidth=2, label='Multi-Output Model')
    axes[0, 0].set_xlabel('Charging Power (kW)')
    axes[0, 0].set_ylabel('Battery Temperature (°C)')
    axes[0, 0].set_title('Battery Temperature vs Charging Power (Temp=20°C, SOC=50%)')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Efficiency vs charging power
    axes[0, 1].plot(charging_powers, predictions['attention'][:, 1], 'b-', linewidth=2, label='Attention Model')
    if 'multi_output' in predictions:
        axes[0, 1].plot(charging_powers, predictions['multi_output'][:, 1], 'g--', linewidth=2, label='Multi-Output Model')
    axes[0, 1].set_xlabel('Charging Power (kW)')
    axes[0, 1].set_ylabel('Charging Efficiency')
    axes[0, 1].set_title('Charging Efficiency vs Charging Power (Temp=20°C, SOC=50%)')
    axes[0, 1].legend()
    axes[0, 1].grid(True)
    
    # Difference in battery temperature predictions
    if 'multi_output' in predictions:
        diff_temp = predictions['attention'][:, 0] - predictions['multi_output'][:, 0]
        axes[1, 0].plot(charging_powers, diff_temp, 'r-', linewidth=2)
        axes[1, 0].set_xlabel('Charging Power (kW)')
        axes[1, 0].set_ylabel('Temperature Difference (°C)')
        axes[1, 0].set_title('Difference in Battery Temperature Predictions')
        axes[1, 0].grid(True)
        axes[1, 0].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    
    # Difference in efficiency predictions
    if 'multi_output' in predictions:
        diff_eff = predictions['attention'][:, 1] - predictions['multi_output'][:, 1]
        axes[1, 1].plot(charging_powers, diff_eff, 'r-', linewidth=2)
        axes[1, 1].set_xlabel('Charging Power (kW)')
        axes[1, 1].set_ylabel('Efficiency Difference')
        axes[1, 1].set_title('Difference in Efficiency Predictions')
        axes[1, 1].grid(True)
        axes[1, 1].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.savefig('05_model_comparison_charging_power.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Charging power comparison saved to '05_model_comparison_charging_power.png'")

def compare_soc_effect(models, scalers):
    """Compare how outputs change with varying SOC when temperature=20, charging power=10"""
    print("Comparing effect of SOC (temperature=20, charging power=10)...")
    
    # Create input data: temperature=20, charging power=10, SOC varies
    ambient_temp = 20
    charging_power = 10
    socs = np.linspace(10, 90, 100)  # SOC from 10% to 90%
    
    # Prepare inputs
    inputs = np.column_stack([
        socs,
        np.full_like(socs, charging_power),
        np.full_like(socs, ambient_temp)
    ])
    
    # Get predictions from both models
    predictions = {}
    
    # Attention model predictions
    if models['attention'] is not None:
        inputs_scaled = scalers['attention_input'].transform(inputs)
        inputs_tensor = torch.from_numpy(inputs_scaled).float()
        
        models['attention'].eval()
        with torch.no_grad():
            battery_temp_pred, efficiency_pred, _, _ = models['attention'](inputs_tensor)
        
        outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
        predictions['attention'] = scalers['attention_output'].inverse_transform(outputs)
    
    # Multi-output model predictions
    if models['multi_output'] is not None:
        inputs_scaled = scalers['multi_output_input'].transform(inputs)
        inputs_tensor = torch.from_numpy(inputs_scaled).float()
        
        models['multi_output'].eval()
        with torch.no_grad():
            battery_temp_pred, efficiency_pred = models['multi_output'](inputs_tensor)
        
        outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
        predictions['multi_output'] = scalers['multi_output_output'].inverse_transform(outputs)
    
    # Plot comparison results
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Battery temperature vs SOC
    axes[0, 0].plot(socs, predictions['attention'][:, 0], 'b-', linewidth=2, label='Attention Model')
    if 'multi_output' in predictions:
        axes[0, 0].plot(socs, predictions['multi_output'][:, 0], 'g--', linewidth=2, label='Multi-Output Model')
    axes[0, 0].set_xlabel('SOC (%)')
    axes[0, 0].set_ylabel('Battery Temperature (°C)')
    axes[0, 0].set_title('Battery Temperature vs SOC (Temp=20°C, Power=10kW)')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Efficiency vs SOC
    axes[0, 1].plot(socs, predictions['attention'][:, 1], 'b-', linewidth=2, label='Attention Model')
    if 'multi_output' in predictions:
        axes[0, 1].plot(socs, predictions['multi_output'][:, 1], 'g--', linewidth=2, label='Multi-Output Model')
    axes[0, 1].set_xlabel('SOC (%)')
    axes[0, 1].set_ylabel('Charging Efficiency')
    axes[0, 1].set_title('Charging Efficiency vs SOC (Temp=20°C, Power=10kW)')
    axes[0, 1].legend()
    axes[0, 1].grid(True)
    
    # Difference in battery temperature predictions
    if 'multi_output' in predictions:
        diff_temp = predictions['attention'][:, 0] - predictions['multi_output'][:, 0]
        axes[1, 0].plot(socs, diff_temp, 'r-', linewidth=2)
        axes[1, 0].set_xlabel('SOC (%)')
        axes[1, 0].set_ylabel('Temperature Difference (°C)')
        axes[1, 0].set_title('Difference in Battery Temperature Predictions')
        axes[1, 0].grid(True)
        axes[1, 0].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    
    # Difference in efficiency predictions
    if 'multi_output' in predictions:
        diff_eff = predictions['attention'][:, 1] - predictions['multi_output'][:, 1]
        axes[1, 1].plot(socs, diff_eff, 'r-', linewidth=2)
        axes[1, 1].set_xlabel('SOC (%)')
        axes[1, 1].set_ylabel('Efficiency Difference')
        axes[1, 1].set_title('Difference in Efficiency Predictions')
        axes[1, 1].grid(True)
        axes[1, 1].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.savefig('05_model_comparison_soc.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("SOC comparison saved to '05_model_comparison_soc.png'")

def compare_temperature_effect(models, scalers):
    """Compare how outputs change with varying temperature when SOC=50, charging power=10"""
    print("Comparing effect of ambient temperature (SOC=50, charging power=10)...")
    
    # Create input data: SOC=50, charging power=10, temperature varies
    soc = 50
    charging_power = 10
    temperatures = np.linspace(0, 40, 100)  # Temperature from 0°C to 40°C
    
    # Prepare inputs
    inputs = np.column_stack([
        np.full_like(temperatures, soc),
        np.full_like(temperatures, charging_power),
        temperatures
    ])
    
    # Get predictions from both models
    predictions = {}
    
    # Attention model predictions
    if models['attention'] is not None:
        inputs_scaled = scalers['attention_input'].transform(inputs)
        inputs_tensor = torch.from_numpy(inputs_scaled).float()
        
        models['attention'].eval()
        with torch.no_grad():
            battery_temp_pred, efficiency_pred, _, _ = models['attention'](inputs_tensor)
        
        outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
        predictions['attention'] = scalers['attention_output'].inverse_transform(outputs)
    
    # Multi-output model predictions
    if models['multi_output'] is not None:
        inputs_scaled = scalers['multi_output_input'].transform(inputs)
        inputs_tensor = torch.from_numpy(inputs_scaled).float()
        
        models['multi_output'].eval()
        with torch.no_grad():
            battery_temp_pred, efficiency_pred = models['multi_output'](inputs_tensor)
        
        outputs = torch.cat([battery_temp_pred, efficiency_pred], dim=1).numpy()
        predictions['multi_output'] = scalers['multi_output_output'].inverse_transform(outputs)
    
    # Plot comparison results
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Battery temperature vs ambient temperature
    axes[0, 0].plot(temperatures, predictions['attention'][:, 0], 'b-', linewidth=2, label='Attention Model')
    if 'multi_output' in predictions:
        axes[0, 0].plot(temperatures, predictions['multi_output'][:, 0], 'g--', linewidth=2, label='Multi-Output Model')
    axes[0, 0].set_xlabel('Ambient Temperature (°C)')
    axes[0, 0].set_ylabel('Battery Temperature (°C)')
    axes[0, 0].set_title('Battery Temperature vs Ambient Temperature (SOC=50%, Power=10kW)')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Efficiency vs ambient temperature
    axes[0, 1].plot(temperatures, predictions['attention'][:, 1], 'b-', linewidth=2, label='Attention Model')
    if 'multi_output' in predictions:
        axes[0, 1].plot(temperatures, predictions['multi_output'][:, 1], 'g--', linewidth=2, label='Multi-Output Model')
    axes[0, 1].set_xlabel('Ambient Temperature (°C)')
    axes[0, 1].set_ylabel('Charging Efficiency')
    axes[0, 1].set_title('Charging Efficiency vs Ambient Temperature (SOC=50%, Power=10kW)')
    axes[0, 1].legend()
    axes[0, 1].grid(True)
    
    # Difference in battery temperature predictions
    if 'multi_output' in predictions:
        diff_temp = predictions['attention'][:, 0] - predictions['multi_output'][:, 0]
        axes[1, 0].plot(temperatures, diff_temp, 'r-', linewidth=2)
        axes[1, 0].set_xlabel('Ambient Temperature (°C)')
        axes[1, 0].set_ylabel('Temperature Difference (°C)')
        axes[1, 0].set_title('Difference in Battery Temperature Predictions')
        axes[1, 0].grid(True)
        axes[1, 0].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    
    # Difference in efficiency predictions
    if 'multi_output' in predictions:
        diff_eff = predictions['attention'][:, 1] - predictions['multi_output'][:, 1]
        axes[1, 1].plot(temperatures, diff_eff, 'r-', linewidth=2)
        axes[1, 1].set_xlabel('Ambient Temperature (°C)')
        axes[1, 1].set_ylabel('Efficiency Difference')
        axes[1, 1].set_title('Difference in Efficiency Predictions')
        axes[1, 1].grid(True)
        axes[1, 1].axhline(y=0, color='k', linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.savefig('05_model_comparison_temperature.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Temperature comparison saved to '05_model_comparison_temperature.png'")

def main():
    # Set random seeds for reproducibility
    random_seed = 999
    random.seed(random_seed)
    np.random.seed(random_seed)
    torch.manual_seed(random_seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    
    # Select device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Load models and scalers
    models, scalers = load_models_and_scalers()
    if models['attention'] is None and models['multi_output'] is None:
        print("No models loaded. Exiting.")
        return
    
    # Move models to device
    if models['attention'] is not None:
        models['attention'] = models['attention'].to(device).float()
    if models['multi_output'] is not None:
        models['multi_output'] = models['multi_output'].to(device).float()
    
    # Perform comparative analyses
    compare_charging_power_effect(models, scalers)
    compare_soc_effect(models, scalers)
    compare_temperature_effect(models, scalers)
    
    print("All comparative analyses completed successfully!")

if __name__ == "__main__":
    main()