import os
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

# =========================
#   Model definition
# =========================
class ImprovedAttentionMultiOutputNet(nn.Module):
    def __init__(self, input_size=3, attention_hidden_size=64,
                 shared_layer_sizes=None, temp_layer_sizes=None, eff_layer_sizes=None):
        super().__init__()
        self.temp_attention = nn.Sequential(
            nn.Linear(input_size, attention_hidden_size),
            nn.Tanh(),
            nn.Linear(attention_hidden_size, input_size),
            nn.Softmax(dim=1)
        )
        self.eff_attention = nn.Sequential(
            nn.Linear(input_size, attention_hidden_size),
            nn.Tanh(),
            nn.Linear(attention_hidden_size, input_size),
            nn.Softmax(dim=1)
        )
        shared_layers, shared_in = [], input_size
        for out_f in shared_layer_sizes:
            shared_layers += [nn.Linear(shared_in, out_f), nn.ReLU()]
            shared_in = out_f
        self.shared_layers = nn.Sequential(*shared_layers)

        temp_layers, temp_in = [], shared_layer_sizes[-1]
        for i, out_f in enumerate(temp_layer_sizes):
            temp_layers.append(nn.Linear(temp_in, out_f))
            if i < len(temp_layer_sizes) - 1:
                temp_layers.append(nn.ReLU())
            temp_in = out_f
        self.temp_branch = nn.Sequential(*temp_layers)

        eff_layers, eff_in = [], shared_layer_sizes[-1]
        for i, out_f in enumerate(eff_layer_sizes):
            eff_layers.append(nn.Linear(eff_in, out_f))
            if i < len(eff_layer_sizes) - 1:
                eff_layers.append(nn.ReLU())
            eff_in = out_f
        self.efficiency_branch = nn.Sequential(*eff_layers)

    def forward(self, x):
        w_t = self.temp_attention(x)
        x_t = x * w_t
        f_t = self.shared_layers(x_t)
        batt_temp = self.temp_branch(f_t)

        x_e_in = torch.cat([x[:, :2], batt_temp], dim=1)
        w_e = self.eff_attention(x_e_in)
        x_e = x_e_in * w_e
        f_e = self.shared_layers(x_e)
        eff = self.efficiency_branch(f_e)
        return batt_temp, eff, w_t, w_e

# =========================
#   Paths & I/O
# =========================
MODEL_PATH   = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\Model_Improved_Attention_charging_best.sd"
SCALER_X     = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_input.pkl"
SCALER_Y     = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_output.pkl"
OUTPUT_DIR   = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# =========================
#   Load model/scalers
# =========================
model = ImprovedAttentionMultiOutputNet(
    input_size=3,
    attention_hidden_size=95,
    shared_layer_sizes=[107, 114, 81],
    temp_layer_sizes=[120, 121, 1],
    eff_layer_sizes=[38, 1]
)
model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu"))
model.eval()

input_scaler  = joblib.load(SCALER_X)
output_scaler = joblib.load(SCALER_Y)

# =========================
#   Settings
# =========================
FULL_POWER_RANGE = np.linspace(4.0, 11.0, 20)  # kW candidates
TOP_N_CANDIDATES = 10
BATTERY_CAPACITY_KWH = 64
TARGET_SOC = 100.0
MAX_MINUTES = 480  # 8h cap for x-axis
INITIAL_BATT_TEMP_C = 30.0
P_EPS = 0.05        # "zero" power threshold in kW
ZERO_WINDOW = 30    # need 30s of ~zero to declare end-of-charge

temp_groups = [
    ("very_low_temp",  "Very low temperature"),
    ("medium_temp",    "Medium temperature"),
    ("high_temp",      "High temperature"),
]

# =========================
#   Helpers
# =========================
def fname(p_kw: int | float, temp_tag: str) -> str:
    return f"synthetic_{int(p_kw)}kW_{temp_tag}.csv"

def load_df(path: str) -> pd.DataFrame:
    df = pd.read_csv(path).rename(columns={
        'ChargeLinePower264': 'p_ac',
        'SOCave292': 'SoC',
        'VCRIGHT_tempAmbientRaw': 'T_amb'
    })
    df = df.dropna(subset=['p_ac', 'SoC', 'T_amb']).reset_index(drop=True)
    return df

def model_predict(soc: float, p_ac: float, t_amb: float):
    """Return (temp_pred_C, eff_pred_frac)."""
    x = np.array([[soc, p_ac, t_amb]], dtype=np.float32)
    xs = input_scaler.transform(x)
    xt = torch.tensor(xs, dtype=torch.float32)
    with torch.no_grad():
        bt, eff, _, _ = model(xt)
        y = torch.cat([bt, eff], dim=1).numpy()
    temp_pred, eff_pred = output_scaler.inverse_transform(y).flatten()
    return float(temp_pred), float(eff_pred)  # eff_pred in [0,1]

def pick_top_candidates(soc0: float, t_amb0: float,
                        full_range=FULL_POWER_RANGE, top_n=TOP_N_CANDIDATES):
    scores = []
    for p in full_range:
        t, e = model_predict(soc0, p, t_amb0)
        score = e - max(0.0, t - 35.0) * 0.5
        scores.append((p, score))
    scores.sort(key=lambda z: z[1], reverse=True)
    return np.array([p for p, _ in scores[:top_n]], dtype=float)

def run_greedy_optimization(df_base: pd.DataFrame):
    """Minute-step greedy AMONN over FULL session length (<= MAX_MINUTES).
       Returns:
         opt_p_min (list, kW)           # full length incl. post-EoC zeros
         pred_t_min (list, °C)          # full length incl. post-EoC cooling @ P=0
         amb_t_min  (list, °C)          # full length ambient (minute)
         end_minute (int)               # first minute index where P=0 after SoC=100%
    """
    total_min = min(MAX_MINUTES, len(df_base) // 60)
    soc = float(df_base.loc[0, 'SoC'])
    candidates = pick_top_candidates(soc, float(df_base.loc[0, 'T_amb']))

    opt_p, pred_t, amb_t = [], [], []
    end_minute = None
    reached = False

    for t in range(total_min):
        idx = t * 60
        T_amb = float(df_base.loc[idx, 'T_amb'])
        amb_t.append(T_amb)

        if reached or soc >= TARGET_SOC:
            reached = True
            opt_p.append(0.0)
            t_batt, _ = model_predict(soc, 0.0, T_amb)
            pred_t.append(INITIAL_BATT_TEMP_C if t == 0 else float(t_batt))
            if end_minute is None:
                end_minute = t
            continue

        best_score, best_p, best_t, best_eff = -np.inf, 0.0, INITIAL_BATT_TEMP_C, 0.0
        for p in candidates:
            t_batt_model, eff = model_predict(soc, p, T_amb)
            t_for_score = INITIAL_BATT_TEMP_C if t == 0 else t_batt_model
            score = eff - max(0.0, t_for_score - 35.0) * 0.5
            if score > best_score:
                best_score = score
                best_p = p
                best_t = (INITIAL_BATT_TEMP_C if t == 0 else t_batt_model)
                best_eff = eff

        opt_p.append(float(best_p))
        pred_t.append(float(best_t))

        # Delivered-energy SoC update: ΔSoC[%] = (P_in * η * (1/60) h) / C_bat * 100
        soc += (best_p * best_eff) / BATTERY_CAPACITY_KWH * (1.0 / 60.0) * 100.0
        soc = min(soc, 100.0)

    if end_minute is None:
        end_minute = len(opt_p)

    if len(pred_t) > 0:
        pred_t[0] = INITIAL_BATT_TEMP_C

    return opt_p, pred_t, amb_t, end_minute

def find_active_segment(power_sec: np.ndarray,
                        p_eps: float = P_EPS,
                        zero_window: int = ZERO_WINDOW) -> tuple[int, int]:
    n = len(power_sec)
    start = 0
    while start < n and power_sec[start] <= p_eps:
        start += 1
    if start >= n:
        return n, n
    end = n
    i = start
    while i + zero_window <= n:
        if np.all(power_sec[i:i+zero_window] <= p_eps):
            end = i
            break
        i += 1
    return start, end

def summarize_series(power_sec: np.ndarray, start: int, end: int):
    if end <= start:
        return 0.0, 0.0, 0.0
    active = power_sec[start:end]
    duration_sec = len(active)
    energy_kWh = float(np.sum(active) / 3600.0)
    duration_min = duration_sec / 60.0
    avg_power_kW = (energy_kWh / (duration_sec / 3600.0)) if duration_sec > 0 else 0.0
    return duration_min, energy_kWh, avg_power_kW

def series_per_minute(power_sec: np.ndarray, total_min: int) -> np.ndarray:
    out = np.zeros(total_min, dtype=float)
    n = len(power_sec)
    for m in range(total_min):
        s = m * 60
        e = min(s + 60, n)
        out[m] = 0.0 if s >= n else float(np.mean(power_sec[s:e]))
    return out

def predict_temp_series_full(df: pd.DataFrame,
                             p_minute: np.ndarray,
                             initial_temp_c: float = INITIAL_BATT_TEMP_C) -> np.ndarray:
    """Per-minute temperature with SoC evolution that uses delivered energy (η-weighted)."""
    total_min = len(p_minute)
    temps = np.zeros(total_min, dtype=float)
    soc = float(df.loc[0, 'SoC'])
    for m in range(total_min):
        idx = min(m * 60, len(df) - 1)
        T_amb = float(df.loc[idx, 'T_amb'])
        p_m = float(p_minute[m])
        t_pred, eff_pred = model_predict(soc, p_m, T_amb)
        if m == 0:
            t_pred = initial_temp_c
        temps[m] = float(t_pred)
        soc += (p_m * eff_pred) / BATTERY_CAPACITY_KWH * (1.0 / 60.0) * 100.0
        soc = min(soc, 100.0)
    return temps

def eff_and_pout_series_model(df: pd.DataFrame,
                              p_minute: np.ndarray,
                              initial_temp_c: float = INITIAL_BATT_TEMP_C):
    """Return arrays (eff_frac, P_out_kW) per minute using the model, evolving SoC with delivered energy."""
    total_min = len(p_minute)
    effs = np.zeros(total_min, dtype=float)
    pouts = np.zeros(total_min, dtype=float)
    soc = float(df.loc[0, 'SoC'])
    for m in range(total_min):
        idx = min(m * 60, len(df) - 1)
        T_amb = float(df.loc[idx, 'T_amb'])
        p_m = float(p_minute[m])
        _, eff_pred = model_predict(soc, p_m, T_amb)
        effs[m] = eff_pred
        pouts[m] = p_m * eff_pred
        soc += (p_m * eff_pred) / BATTERY_CAPACITY_KWH * (1.0 / 60.0) * 100.0
        soc = min(soc, 100.0)
    return effs, pouts

def time_axis_minutes(n_points: int) -> np.ndarray:
    return np.arange(n_points, dtype=float)

# =========================
#   Plot + Compute + Save
# =========================
fig, axs = plt.subplots(nrows=1, ncols=3, figsize=(16, 4.8), sharex=False, sharey=True)
if not isinstance(axs, np.ndarray):
    axs = np.array([axs])

summary_rows = []
permin_rows = []

for ax, (temp_tag, _title_unused) in zip(axs, temp_groups):
    files = {4: fname(4, temp_tag), 8: fname(8, temp_tag), 11: fname(11, temp_tag)}
    dfs: dict[int, pd.DataFrame] = {}
    for p, f in files.items():
        if not os.path.exists(f):
            print(f"[WARN] Missing file: %s" % f)
            continue
        dfs[p] = load_df(f)

    base_key = 8 if 8 in dfs else (sorted(dfs.keys())[0] if dfs else None)
    if base_key is None:
        ax.text(0.5, 0.5, "No data", ha='center', va='center', transform=ax.transAxes)
        continue

    df_base = dfs[base_key]
    session_len_sec = len(df_base)
    total_min = min(MAX_MINUTES, session_len_sec // 60)

    # ---------- AMONN ----------
    opt_p_min, pred_t_amonn_min, amb_t_min, end_minute = run_greedy_optimization(df_base)

    # Per-second AMONN power (full)
    t_min_idx = np.arange(len(opt_p_min), dtype=float)
    t_min_1s = np.linspace(0.0, len(opt_p_min) - 1, session_len_sec)
    opt_interp = interp1d(t_min_idx, opt_p_min, kind='linear', fill_value='extrapolate')
    opt_pw_1s_full = opt_interp(t_min_1s)

    # Active window for metrics (grid/input energy)
    end_sec_amonn = int(end_minute * 60)
    end_sec_amonn = min(end_sec_amonn, len(opt_pw_1s_full))
    opt_pw_1s_active = opt_pw_1s_full[:end_sec_amonn]
    dur_min_a = len(opt_pw_1s_active) / 60.0
    energy_kWh_a = float(np.sum(opt_pw_1s_active) / 3600.0)  # input energy
    avg_kW_a = (energy_kWh_a / (len(opt_pw_1s_active) / 3600.0)) if len(opt_pw_1s_active) else 0.0
    batt_min_a = float(np.min(pred_t_amonn_min[:end_minute])) if end_minute > 0 else np.nan
    batt_max_a = float(np.max(pred_t_amonn_min[:end_minute])) if end_minute > 0 else np.nan

    summary_rows.append({
        "temp_group": temp_tag, "scenario": "AMONN",
        "duration_min": dur_min_a, "avg_power_kW": avg_kW_a,
        "total_energy_kWh": energy_kWh_a,
        "batt_temp_min_C": batt_min_a, "batt_temp_max_C": batt_max_a
    })

    # ---------- Fixed power scenarios ----------
    per_scen_full_sec = {}
    per_scen_min = {}
    batt_temp_min_series = {}
    df_for_amb = {}

    for scen_p, style in [(11, '-'), (8, '--'), (4, ':')]:
        if scen_p not in dfs:
            continue
        dfp = dfs[scen_p]
        df_for_amb[scen_p] = dfp
        y_full = dfp['p_ac'].values  # per-second
        per_scen_full_sec[scen_p] = y_full

        # metrics on active window (input power)
        start_idx, end_idx = find_active_segment(y_full, p_eps=P_EPS, zero_window=ZERO_WINDOW)
        dur_min, energy_kWh, avg_kW = summarize_series(y_full, start_idx, end_idx)

        # temp range within active window (model-based)
        _p_min_active = series_per_minute(y_full[start_idx:end_idx], (end_idx - start_idx)//60)
        _t_series_active = predict_temp_series_full(dfp.iloc[start_idx:], _p_min_active)
        tminC = float(np.min(_t_series_active)) if len(_t_series_active) else np.nan
        tmaxC = float(np.max(_t_series_active)) if len(_t_series_active) else np.nan

        summary_rows.append({
            "temp_group": temp_tag, "scenario": f"{scen_p} kW",
            "duration_min": dur_min, "avg_power_kW": avg_kW,
            "total_energy_kWh": energy_kWh,
            "batt_temp_min_C": tminC, "batt_temp_max_C": tmaxC
        })

        # full per-minute series (incl. zeros) + temps
        p_minute_full = series_per_minute(y_full, total_min)
        per_scen_min[scen_p] = p_minute_full
        batt_temp_min_series[scen_p] = predict_temp_series_full(dfp, p_minute_full)

    # ---------- Per-minute dataset (ALL scenarios) with MODEL efficiency + P_out ----------
    # AMONN rows (model-based eff)
    amonn_p_in = np.array(opt_p_min[:total_min], dtype=float)
    amonn_batt_full = np.array(pred_t_amonn_min[:total_min], dtype=float)
    amb_full = np.array(amb_t_min[:total_min], dtype=float)
    amonn_eff_frac, amonn_p_out = eff_and_pout_series_model(df_base, amonn_p_in)
    for m in range(total_min):
        permin_rows.append({
            "temp_group": temp_tag, "scenario": "AMONN", "minute": m,
            "P_in_kW": float(amonn_p_in[m]),
            "eff_frac": float(amonn_eff_frac[m]),
            "eff_pct": float(amonn_eff_frac[m] * 100.0),
            "P_out_kW": float(amonn_p_out[m]),
            "Batt_Temp_C": float(amonn_batt_full[m]) if m < len(amonn_batt_full) else np.nan,
            "Amb_Temp_C":  float(amb_full[m]) if m < len(amb_full) else np.nan
        })

    # Fixed-power rows (model-based eff)
    for scen_p in [11, 8, 4]:
        if scen_p not in per_scen_min:
            continue
        p_min_series = per_scen_min[scen_p]
        batt_series  = batt_temp_min_series[scen_p]
        dfp = df_for_amb[scen_p]
        eff_frac_series, p_out_series = eff_and_pout_series_model(dfp, p_min_series)
        for m in range(total_min):
            amb_val = float(dfp.loc[min(m*60, len(dfp)-1), 'T_amb'])
            bval = float(batt_series[m]) if m < len(batt_series) else np.nan
            permin_rows.append({
                "temp_group": temp_tag, "scenario": f"{scen_p} kW", "minute": m,
                "P_in_kW": float(p_min_series[m]) if m < len(p_min_series) else 0.0,
                "eff_frac": float(eff_frac_series[m]),
                "eff_pct": float(eff_frac_series[m] * 100.0),
                "P_out_kW": float(p_out_series[m]),
                "Batt_Temp_C": bval, "Amb_Temp_C": amb_val
            })

    # ---------- Plotting (keep zero-power tails) ----------
    def plot_power(ax, series, label, style, color='black', lw=1.8):
        t_min_axis = np.arange(len(series)) / 60.0
        return ax.plot(t_min_axis, series, label=label, color=color, linestyle=style, linewidth=lw)[0]

    per_scen_full_sec = {k: v for k, v in per_scen_full_sec.items()}  # just to satisfy lints
    h11 = h8 = h4 = None
    if 11 in per_scen_full_sec:
        h11 = plot_power(ax, per_scen_full_sec[11], "11 kW", '-')
    if 8 in per_scen_full_sec:
        h8 = plot_power(ax, per_scen_full_sec[8], "8 kW", '--')
    if 4 in per_scen_full_sec:
        h4 = plot_power(ax, per_scen_full_sec[4], "4 kW",  ':')

    # AMONN (green)
    t_amonn_min_axis_full = np.arange(len(opt_pw_1s_full)) / 60.0
    hamonn = ax.plot(t_amonn_min_axis_full, opt_pw_1s_full, label="AMONN_GO",
                     color='green', linestyle='-', linewidth=2.2)[0]

    # Temperatures (right)
    ax2 = ax.twinx()
    hTamb  = ax2.plot(np.arange(len(amb_t_min)), amb_t_min, label="Amb. Temp",
                      color='orange', linestyle='-.', linewidth=1.4)[0]
    hTbattAm = ax2.plot(np.arange(len(pred_t_amonn_min)), pred_t_amonn_min,
                        label="Batt. Temp. AMONN",
                        color='red', linestyle='-.', linewidth=1.8, alpha=1.0)[0]

    ax2.set_ylabel("Temperature (°C)", fontsize=12)

    # Right axis limits
    vals_for_ylim = []
    for arr in [amb_t_min, pred_t_amonn_min,
                batt_temp_min_series.get(11, []),
                batt_temp_min_series.get(8,  []),
                batt_temp_min_series.get(4,  [])]:
        if len(arr):
            vals_for_ylim += list(arr)
    if vals_for_ylim:
        tmax = max(40.0, max(vals_for_ylim) + 5.0)
        ax2.set_ylim(-15.0, tmax)

    # Axes cosmetics
    ax.grid(True, alpha=0.35)
    ax.set_ylim(0, 12)
    longest_min = max(
        len(per_scen_full_sec.get(11, [])) if 11 in per_scen_full_sec else 0,
        len(per_scen_full_sec.get(8,  [])) if 8  in per_scen_full_sec else 0,
        len(per_scen_full_sec.get(4,  [])) if 4  in per_scen_full_sec else 0,
        len(opt_pw_1s_full)
    ) / 60.0
    ax.set_xlim(0, max(longest_min, total_min))
    ax.set_ylabel("Power (kW)", fontsize=12)
    ax.set_xlabel("Time (minutes)", fontsize=12)

    # Legends
    power_handles = []
    if h11 is not None: power_handles.append(h11)
    power_handles.append(hamonn)
    if h8 is not None: power_handles.append(h8)
    if h4 is not None: power_handles.append(h4)
    ax.legend(power_handles,
              [h.get_label() for h in power_handles],
              loc="center right", ncol=1, framealpha=0.9, fontsize=9)

    temp_handles = [h for h in [hTbattAm, hTamb] if h is not None]
    ax2.legend(temp_handles,
               [h.get_label() for h in temp_handles],
               loc="upper right", framealpha=0.9, fontsize=9)

    # ---------- Save per-second FULL time-series (incl. zeros) ----------
    max_len = max(
        len(per_scen_full_sec.get(11, [])) if 11 in per_scen_full_sec else 0,
        len(per_scen_full_sec.get(8,  [])) if 8  in per_scen_full_sec else 0,
        len(per_scen_full_sec.get(4,  [])) if 4  in per_scen_full_sec else 0,
        len(opt_pw_1s_full)
    )
    def pad(arr, L):
        out = np.full(L, np.nan, dtype=float)
        out[:len(arr)] = arr
        return out
    ts_df = pd.DataFrame({
        "time_s": np.arange(max_len, dtype=int),
        "p_11kW": pad(per_scen_full_sec.get(11, np.array([])), max_len),
        "p_8kW":  pad(per_scen_full_sec.get(8,  np.array([])), max_len),
        "p_4kW":  pad(per_scen_full_sec.get(4,  np.array([])), max_len),
        "p_AMONN": pad(opt_pw_1s_full, max_len),
    })
    ts_path = os.path.join(OUTPUT_DIR, f"timeseries_power_{temp_tag}.csv")
    ts_df.to_csv(ts_path, index=False)

plt.tight_layout()
plt.subplots_adjust(wspace=0.35)  # increase horizontal space between subplots
plt.show()

# =========================
#   Save CSVs
# =========================
# 1) Per-minute dataset with MODEL efficiency + output power (includes all scenarios)
permin_df = pd.DataFrame(permin_rows, columns=[
    "temp_group","scenario","minute","P_in_kW","eff_frac","eff_pct","P_out_kW","Batt_Temp_C","Amb_Temp_C"
])
permin_csv_path = os.path.join(OUTPUT_DIR, "perminute_power_efficiency.csv")
permin_df.to_csv(permin_csv_path, index=False)

# 2) Summary metrics in exact order requested
summary_df = pd.DataFrame(summary_rows)
summary_df = summary_df[[
    "temp_group","scenario","duration_min","avg_power_kW","total_energy_kWh","batt_temp_min_C","batt_temp_max_C"
]]
summary_csv_path = os.path.join(OUTPUT_DIR, "summary_metrics.csv")
summary_df.to_csv(summary_csv_path, index=False)

print(f"Per-minute dataset saved to: {permin_csv_path}")
print(f"Summary metrics saved to:   {summary_csv_path}")
fig_path = os.path.join(OUTPUT_DIR, "fig10.png")
fig.savefig(fig_path, dpi=300)







































# import os
# import torch
# import torch.nn as nn
# import numpy as np
# import pandas as pd
# import joblib
# import matplotlib.pyplot as plt
# from scipy.interpolate import interp1d

# # =========================
# #   Model definition
# # =========================
# class ImprovedAttentionMultiOutputNet(nn.Module):
#     def __init__(self, input_size=3, attention_hidden_size=64,
#                  shared_layer_sizes=None, temp_layer_sizes=None, eff_layer_sizes=None):
#         super().__init__()
#         self.temp_attention = nn.Sequential(
#             nn.Linear(input_size, attention_hidden_size),
#             nn.Tanh(),
#             nn.Linear(attention_hidden_size, input_size),
#             nn.Softmax(dim=1)
#         )
#         self.eff_attention = nn.Sequential(
#             nn.Linear(input_size, attention_hidden_size),
#             nn.Tanh(),
#             nn.Linear(attention_hidden_size, input_size),
#             nn.Softmax(dim=1)
#         )
#         shared_layers, shared_in = [], input_size
#         for out_f in shared_layer_sizes:
#             shared_layers += [nn.Linear(shared_in, out_f), nn.ReLU()]
#             shared_in = out_f
#         self.shared_layers = nn.Sequential(*shared_layers)

#         temp_layers, temp_in = [], shared_layer_sizes[-1]
#         for i, out_f in enumerate(temp_layer_sizes):
#             temp_layers.append(nn.Linear(temp_in, out_f))
#             if i < len(temp_layer_sizes) - 1:
#                 temp_layers.append(nn.ReLU())
#             temp_in = out_f
#         self.temp_branch = nn.Sequential(*temp_layers)

#         eff_layers, eff_in = [], shared_layer_sizes[-1]
#         for i, out_f in enumerate(eff_layer_sizes):
#             eff_layers.append(nn.Linear(eff_in, out_f))
#             if i < len(eff_layer_sizes) - 1:
#                 eff_layers.append(nn.ReLU())
#             eff_in = out_f
#         self.efficiency_branch = nn.Sequential(*eff_layers)

#     def forward(self, x):
#         w_t = self.temp_attention(x)
#         x_t = x * w_t
#         f_t = self.shared_layers(x_t)
#         batt_temp = self.temp_branch(f_t)

#         x_e_in = torch.cat([x[:, :2], batt_temp], dim=1)
#         w_e = self.eff_attention(x_e_in)
#         x_e = x_e_in * w_e
#         f_e = self.shared_layers(x_e)
#         eff = self.efficiency_branch(f_e)
#         return batt_temp, eff, w_t, w_e

# # =========================
# #   Paths & I/O
# # =========================
# MODEL_PATH   = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\Model_Improved_Attention_charging_best.sd"
# SCALER_X     = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_input.pkl"
# SCALER_Y     = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_output.pkl"
# OUTPUT_DIR   = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework"
# EFF_FILE     = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\Table.csv"
# os.makedirs(OUTPUT_DIR, exist_ok=True)

# # =========================
# #   Load model/scalers
# # =========================
# model = ImprovedAttentionMultiOutputNet(
#     input_size=3,
#     attention_hidden_size=95,
#     shared_layer_sizes=[107, 114, 81],
#     temp_layer_sizes=[120, 121, 1],
#     eff_layer_sizes=[38, 1]
# )
# model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu"))
# model.eval()

# input_scaler  = joblib.load(SCALER_X)
# output_scaler = joblib.load(SCALER_Y)

# # =========================
# #   Settings
# # =========================
# FULL_POWER_RANGE = np.linspace(4.0, 11.0, 20)  # kW candidates
# TOP_N_CANDIDATES = 10
# BATTERY_CAPACITY_KWH = 64
# TARGET_SOC = 100.0
# MAX_MINUTES = 480  # 8h cap for x-axis
# INITIAL_BATT_TEMP_C = 30.0
# P_EPS = 0.05        # "zero" power threshold in kW
# ZERO_WINDOW = 30    # need 30s of ~zero to declare end-of-charge

# temp_groups = [
#     ("very_low_temp",  "Very low temperature"),
#     ("medium_temp",    "Medium temperature"),
#     ("high_temp",      "High temperature"),
# ]

# # =========================
# #   Efficiency table (nearest neighbor)
# # =========================
# def load_eff_table(path: str):
#     eff_df = pd.read_csv(path)
#     if not {'power', 'efficiency'}.issubset(set(eff_df.columns)):
#         raise ValueError("Efficiency CSV must contain columns: 'power', 'efficiency'")
#     eff_df = eff_df.dropna(subset=['power', 'efficiency']).copy()
#     eff_df['power'] = eff_df['power'].astype(float)
#     eff_df['efficiency'] = eff_df['efficiency'].astype(float)
#     # normalize efficiency: if >1 => interpret as %
#     eff_df['eff_frac'] = eff_df['efficiency'].apply(lambda x: x/100.0 if x > 1.0 else x)
#     eff_df = eff_df.sort_values('power').reset_index(drop=True)
#     return eff_df

# eff_table = load_eff_table(EFF_FILE)
# eff_power = eff_table['power'].values
# eff_frac  = eff_table['eff_frac'].values

# def eff_lookup_nearest(p_kw: float) -> tuple[float, float]:
#     """Return (eff_frac, eff_pct) for nearest power in table."""
#     if len(eff_power) == 0:
#         return 1.0, 100.0
#     idx = int(np.argmin(np.abs(eff_power - p_kw)))
#     e = float(eff_frac[idx])
#     return e, e * 100.0

# # =========================
# #   Helpers
# # =========================
# def fname(p_kw: int | float, temp_tag: str) -> str:
#     return f"synthetic_{int(p_kw)}kW_{temp_tag}.csv"

# def load_df(path: str) -> pd.DataFrame:
#     df = pd.read_csv(path).rename(columns={
#         'ChargeLinePower264': 'p_ac',
#         'SOCave292': 'SoC',
#         'VCRIGHT_tempAmbientRaw': 'T_amb'
#     })
#     df = df.dropna(subset=['p_ac', 'SoC', 'T_amb']).reset_index(drop=True)
#     return df

# def model_predict(soc: float, p_ac: float, t_amb: float):
#     x = np.array([[soc, p_ac, t_amb]], dtype=np.float32)
#     xs = input_scaler.transform(x)
#     xt = torch.tensor(xs, dtype=torch.float32)
#     with torch.no_grad():
#         bt, eff, _, _ = model(xt)
#         y = torch.cat([bt, eff], dim=1).numpy()
#     temp_pred, eff_pred = output_scaler.inverse_transform(y).flatten()
#     return float(temp_pred), float(eff_pred)

# def pick_top_candidates(soc0: float, t_amb0: float,
#                         full_range=FULL_POWER_RANGE, top_n=TOP_N_CANDIDATES):
#     scores = []
#     for p in full_range:
#         t, e = model_predict(soc0, p, t_amb0)
#         score = e - max(0.0, t - 35.0) * 0.5
#         scores.append((p, score))
#     scores.sort(key=lambda z: z[1], reverse=True)
#     return np.array([p for p, _ in scores[:top_n]], dtype=float)

# def run_greedy_optimization(df_base: pd.DataFrame):
#     """Minute-step greedy AMONN over FULL session length (<= MAX_MINUTES).
#        Returns:
#          opt_p_min (list, kW)           # full length incl. post-EoC zeros
#          pred_t_min (list, °C)          # full length incl. post-EoC cooling @ P=0
#          amb_t_min  (list, °C)          # full length ambient (minute)
#          end_minute (int)               # first minute index where P=0 after SoC=100%
#     """
#     total_min = min(MAX_MINUTES, len(df_base) // 60)
#     soc = float(df_base.loc[0, 'SoC'])
#     candidates = pick_top_candidates(soc, float(df_base.loc[0, 'T_amb']))

#     opt_p, pred_t, amb_t = [], [], []
#     end_minute = None
#     reached = False

#     for t in range(total_min):
#         idx = t * 60
#         T_amb = float(df_base.loc[idx, 'T_amb'])
#         amb_t.append(T_amb)

#         if reached or soc >= TARGET_SOC:
#             reached = True
#             opt_p.append(0.0)
#             t_batt, _ = model_predict(soc, 0.0, T_amb)
#             pred_t.append(INITIAL_BATT_TEMP_C if t == 0 else float(t_batt))
#             if end_minute is None:
#                 end_minute = t
#             continue

#         best_score, best_p, best_t = -np.inf, 0.0, INITIAL_BATT_TEMP_C
#         for p in candidates:
#             t_batt_model, eff = model_predict(soc, p, T_amb)
#             t_for_score = INITIAL_BATT_TEMP_C if t == 0 else t_batt_model
#             score = eff - max(0.0, t_for_score - 35.0) * 0.5
#             if score > best_score:
#                 best_score = score
#                 best_p = p
#                 best_t = (INITIAL_BATT_TEMP_C if t == 0 else t_batt_model)

#         opt_p.append(float(best_p))
#         pred_t.append(float(best_t))

#         soc += best_p / BATTERY_CAPACITY_KWH * (1.0 / 60.0) * 100.0
#         soc = min(soc, 100.0)

#     if end_minute is None:
#         end_minute = len(opt_p)

#     if len(pred_t) > 0:
#         pred_t[0] = INITIAL_BATT_TEMP_C

#     return opt_p, pred_t, amb_t, end_minute

# def find_active_segment(power_sec: np.ndarray,
#                         p_eps: float = P_EPS,
#                         zero_window: int = ZERO_WINDOW) -> tuple[int, int]:
#     n = len(power_sec)
#     start = 0
#     while start < n and power_sec[start] <= p_eps:
#         start += 1
#     if start >= n:
#         return n, n
#     end = n
#     i = start
#     while i + zero_window <= n:
#         if np.all(power_sec[i:i+zero_window] <= p_eps):
#             end = i
#             break
#         i += 1
#     return start, end

# def summarize_series(power_sec: np.ndarray, start: int, end: int):
#     if end <= start:
#         return 0.0, 0.0, 0.0
#     active = power_sec[start:end]
#     duration_sec = len(active)
#     energy_kWh = float(np.sum(active) / 3600.0)
#     duration_min = duration_sec / 60.0
#     avg_power_kW = (energy_kWh / (duration_sec / 3600.0)) if duration_sec > 0 else 0.0
#     return duration_min, energy_kWh, avg_power_kW

# def series_per_minute(power_sec: np.ndarray, total_min: int) -> np.ndarray:
#     out = np.zeros(total_min, dtype=float)
#     n = len(power_sec)
#     for m in range(total_min):
#         s = m * 60
#         e = min(s + 60, n)
#         out[m] = 0.0 if s >= n else float(np.mean(power_sec[s:e]))
#     return out

# def predict_temp_series_full(df: pd.DataFrame,
#                              p_minute: np.ndarray,
#                              initial_temp_c: float = INITIAL_BATT_TEMP_C) -> np.ndarray:
#     total_min = len(p_minute)
#     temps = np.zeros(total_min, dtype=float)
#     soc = float(df.loc[0, 'SoC'])
#     for m in range(total_min):
#         idx = min(m * 60, len(df) - 1)
#         T_amb = float(df.loc[idx, 'T_amb'])
#         p_m = float(p_minute[m])
#         t_pred, _ = model_predict(soc, p_m, T_amb)
#         if m == 0:
#             t_pred = initial_temp_c
#         temps[m] = float(t_pred)
#         soc += p_m / BATTERY_CAPACITY_KWH * (1.0 / 60.0) * 100.0
#         soc = min(soc, 100.0)
#     return temps

# def time_axis_minutes(n_points: int) -> np.ndarray:
#     return np.arange(n_points, dtype=float)

# # =========================
# #   Plot + Compute + Save
# # =========================
# fig, axs = plt.subplots(nrows=1, ncols=3, figsize=(16, 4.8), sharex=False, sharey=True)
# if not isinstance(axs, np.ndarray):
#     axs = np.array([axs])

# summary_rows = []
# permin_rows = []

# for ax, (temp_tag, _title_unused) in zip(axs, temp_groups):
#     files = {4: fname(4, temp_tag), 8: fname(8, temp_tag), 11: fname(11, temp_tag)}
#     dfs: dict[int, pd.DataFrame] = {}
#     for p, f in files.items():
#         if not os.path.exists(f):
#             print(f"[WARN] Missing file: {f}")
#             continue
#         dfs[p] = load_df(f)

#     base_key = 8 if 8 in dfs else (sorted(dfs.keys())[0] if dfs else None)
#     if base_key is None:
#         ax.text(0.5, 0.5, "No data", ha='center', va='center', transform=ax.transAxes)
#         continue

#     df_base = dfs[base_key]
#     session_len_sec = len(df_base)
#     total_min = min(MAX_MINUTES, session_len_sec // 60)

#     # ---------- AMONN ----------
#     opt_p_min, pred_t_amonn_min, amb_t_min, end_minute = run_greedy_optimization(df_base)

#     # Per-second AMONN power (full)
#     t_min_idx = np.arange(len(opt_p_min), dtype=float)
#     t_min_1s = np.linspace(0.0, len(opt_p_min) - 1, session_len_sec)
#     opt_interp = interp1d(t_min_idx, opt_p_min, kind='linear', fill_value='extrapolate')
#     opt_pw_1s_full = opt_interp(t_min_1s)

#     # Active window for metrics
#     end_sec_amonn = int(end_minute * 60)
#     end_sec_amonn = min(end_sec_amonn, len(opt_pw_1s_full))
#     opt_pw_1s_active = opt_pw_1s_full[:end_sec_amonn]
#     dur_min_a = len(opt_pw_1s_active) / 60.0
#     energy_kWh_a = float(np.sum(opt_pw_1s_active) / 3600.0)
#     avg_kW_a = (energy_kWh_a / (len(opt_pw_1s_active) / 3600.0)) if len(opt_pw_1s_active) else 0.0
#     batt_min_a = float(np.min(pred_t_amonn_min[:end_minute])) if end_minute > 0 else np.nan
#     batt_max_a = float(np.max(pred_t_amonn_min[:end_minute])) if end_minute > 0 else np.nan

#     summary_rows.append({
#         "temp_group": temp_tag, "scenario": "AMONN",
#         "duration_min": dur_min_a, "avg_power_kW": avg_kW_a,
#         "total_energy_kWh": energy_kWh_a,
#         "batt_temp_min_C": batt_min_a, "batt_temp_max_C": batt_max_a
#     })

#     # ---------- Fixed power scenarios ----------
#     per_scen_full_sec = {}
#     per_scen_min = {}
#     batt_temp_min_series = {}
#     df_for_amb = {}

#     for scen_p, style in [(11, '-'), (8, '--'), (4, ':')]:
#         if scen_p not in dfs:
#             continue
#         dfp = dfs[scen_p]
#         df_for_amb[scen_p] = dfp
#         y_full = dfp['p_ac'].values  # per-second
#         per_scen_full_sec[scen_p] = y_full

#         # metrics on active window
#         start_idx, end_idx = find_active_segment(y_full, p_eps=P_EPS, zero_window=ZERO_WINDOW)
#         dur_min, energy_kWh, avg_kW = summarize_series(y_full, start_idx, end_idx)

#         # temp range within active window
#         _p_min_active = series_per_minute(y_full[start_idx:end_idx], (end_idx - start_idx)//60)
#         _t_series_active = predict_temp_series_full(dfp.iloc[start_idx:], _p_min_active)
#         tminC = float(np.min(_t_series_active)) if len(_t_series_active) else np.nan
#         tmaxC = float(np.max(_t_series_active)) if len(_t_series_active) else np.nan

#         summary_rows.append({
#             "temp_group": temp_tag, "scenario": f"{scen_p} kW",
#             "duration_min": dur_min, "avg_power_kW": avg_kW,
#             "total_energy_kWh": energy_kWh,
#             "batt_temp_min_C": tminC, "batt_temp_max_C": tmaxC
#         })

#         # full per-minute series (incl. zeros) + temps
#         p_minute_full = series_per_minute(y_full, total_min)
#         per_scen_min[scen_p] = p_minute_full
#         batt_temp_min_series[scen_p] = predict_temp_series_full(dfp, p_minute_full)

#     # ---------- Per-minute dataset (ALL scenarios) with efficiency + P_out ----------
#     # AMONN rows
#     amonn_p_in = np.array(opt_p_min[:total_min], dtype=float)
#     amonn_batt_full = np.array(pred_t_amonn_min[:total_min], dtype=float)
#     amb_full = np.array(amb_t_min[:total_min], dtype=float)
#     for m in range(total_min):
#         p_in = float(amonn_p_in[m])
#         eff_f, eff_pct = eff_lookup_nearest(p_in)
#         permin_rows.append({
#             "temp_group": temp_tag, "scenario": "AMONN", "minute": m,
#             "P_in_kW": p_in, "eff_frac": eff_f, "eff_pct": eff_pct,
#             "P_out_kW": p_in * eff_f,
#             "Batt_Temp_C": float(amonn_batt_full[m]) if m < len(amonn_batt_full) else np.nan,
#             "Amb_Temp_C":  float(amb_full[m]) if m < len(amb_full) else np.nan
#         })

#     # Fixed-power rows
#     for scen_p in [11, 8, 4]:
#         if scen_p not in per_scen_min:
#             continue
#         p_min_series = per_scen_min[scen_p]
#         batt_series  = batt_temp_min_series[scen_p]
#         dfp = df_for_amb[scen_p]
#         for m in range(total_min):
#             p_in = float(p_min_series[m]) if m < len(p_min_series) else 0.0
#             eff_f, eff_pct = eff_lookup_nearest(p_in)
#             amb_val = float(dfp.loc[min(m*60, len(dfp)-1), 'T_amb'])
#             bval = float(batt_series[m]) if m < len(batt_series) else np.nan
#             permin_rows.append({
#                 "temp_group": temp_tag, "scenario": f"{scen_p} kW", "minute": m,
#                 "P_in_kW": p_in, "eff_frac": eff_f, "eff_pct": eff_pct,
#                 "P_out_kW": p_in * eff_f,
#                 "Batt_Temp_C": bval, "Amb_Temp_C": amb_val
#             })

#     # ---------- Plotting (keep zero-power tails) ----------
#     def plot_power(ax, series, label, style, color='black', lw=1.8):
#         t_min_axis = np.arange(len(series)) / 60.0
#         return ax.plot(t_min_axis, series, label=label, color=color, linestyle=style, linewidth=lw)[0]

#     h11 = h8 = h4 = None
#     if 11 in per_scen_full_sec:
#         h11 = plot_power(ax, per_scen_full_sec[11], "11 kW", '-')
#     if 8 in per_scen_full_sec:
#         h8 = plot_power(ax, per_scen_full_sec[8], "8 kW", '--')
#     if 4 in per_scen_full_sec:
#         h4 = plot_power(ax, per_scen_full_sec[4], "4 kW", ':')

#     # AMONN (green)
#     t_amonn_min_axis_full = np.arange(len(opt_pw_1s_full)) / 60.0
#     hamonn = ax.plot(t_amonn_min_axis_full, opt_pw_1s_full, label="AMONN",
#                      color='green', linestyle='-', linewidth=2.2)[0]

#     # Temperatures (right) — ALL scenarios; 11/8/4 light red; AMONN strong red
#     ax2 = ax.twinx()
#     # Ambient
#     hTamb  = ax2.plot(np.arange(len(amb_t_min)), amb_t_min, label="Amb. Temp",
#                       color='orange', linestyle='-.', linewidth=1.4)[0]
#     # Battery temps (linestyle matches power)
#     alpha_light = 0.35
#     # hTbatt11 = ax2.plot(np.arange(len(batt_temp_min_series.get(11, []))),
#     #                     batt_temp_min_series.get(11, []),
#     #                     label="Batt. Temp. 11 kW",
#     #                     color='red', linestyle='-', linewidth=1.0, alpha=alpha_light)[0] \
#     #             if len(batt_temp_min_series.get(11, [])) else None
#     # hTbatt08 = ax2.plot(np.arange(len(batt_temp_min_series.get(8, []))),
#     #                     batt_temp_min_series.get(8, []),
#     #                     label="Batt. Temp. 8 kW",
#     #                     color='red', linestyle='--', linewidth=1.0, alpha=alpha_light)[0] \
#     #             if len(batt_temp_min_series.get(8, [])) else None
#     # hTbatt04 = ax2.plot(np.arange(len(batt_temp_min_series.get(4, []))),
#     #                     batt_temp_min_series.get(4, []),
#     #                     label="Batt. Temp. 4 kW",
#     #                     color='red', linestyle=':', linewidth=1.0, alpha=alpha_light)[0] \
#     #             if len(batt_temp_min_series.get(4, [])) else None
#     # AMONN battery temp (highlighted)
#     hTbattAm = ax2.plot(np.arange(len(pred_t_amonn_min)), pred_t_amonn_min,
#                         label="Batt. Temp. AMONN",
#                         color='red', linestyle='-.', linewidth=1.8, alpha=1.0)[0]

#     ax2.set_ylabel("Temperature (°C)", fontsize=12)

#     # Right axis limits
#     vals_for_ylim = []
#     for arr in [amb_t_min, pred_t_amonn_min,
#                 batt_temp_min_series.get(11, []),
#                 batt_temp_min_series.get(8,  []),
#                 batt_temp_min_series.get(4,  [])]:
#         if len(arr):
#             vals_for_ylim += list(arr)
#     if vals_for_ylim:
#         tmax = max(40.0, max(vals_for_ylim) + 5.0)
#         ax2.set_ylim(-15.0, tmax)

#     # Axes cosmetics
#     ax.grid(True, alpha=0.35)
#     ax.set_ylim(0, 12)
#     longest_min = max(
#         len(per_scen_full_sec.get(11, [])),
#         len(per_scen_full_sec.get(8,  [])),
#         len(per_scen_full_sec.get(4,  [])),
#         len(opt_pw_1s_full)
#     ) / 60.0
#     ax.set_xlim(0, max(longest_min, total_min))
#     ax.set_ylabel("Power (kW)", fontsize=12)
#     ax.set_xlabel("Time (minutes)", fontsize=12)

#     # Legends
#     power_handles = []
#     if h11 is not None: power_handles.append(h11)
#     power_handles.append(hamonn)
#     if h8 is not None: power_handles.append(h8)
#     if h4 is not None: power_handles.append(h4)
#     ax.legend(power_handles,
#               [h.get_label() for h in power_handles],
#               loc="center right", ncol=1, framealpha=0.9, fontsize=9)

#     temp_handles = [h for h in [hTbattAm, hTamb] if h is not None]
#     #temp_handles = [h for h in [hTbatt11, hTbattAm, hTbatt08, hTbatt04, hTamb] if h is not None]
    
#     ax2.legend(temp_handles,
#                [h.get_label() for h in temp_handles],
#                loc="upper right", framealpha=0.9, fontsize=9)

#     # ---------- Save per-second FULL time-series (incl. zeros) ----------
#     max_len = max(
#         len(per_scen_full_sec.get(11, [])),
#         len(per_scen_full_sec.get(8,  [])),
#         len(per_scen_full_sec.get(4,  [])),
#         len(opt_pw_1s_full)
#     )
#     def pad(arr, L):
#         out = np.full(L, np.nan, dtype=float)
#         out[:len(arr)] = arr
#         return out
#     ts_df = pd.DataFrame({
#         "time_s": np.arange(max_len, dtype=int),
#         "p_11kW": pad(per_scen_full_sec.get(11, np.array([])), max_len),
#         "p_8kW":  pad(per_scen_full_sec.get(8,  np.array([])), max_len),
#         "p_4kW":  pad(per_scen_full_sec.get(4,  np.array([])), max_len),
#         "p_AMONN": pad(opt_pw_1s_full, max_len),
#     })
#     ts_path = os.path.join(OUTPUT_DIR, f"timeseries_power_{temp_tag}.csv")
#     ts_df.to_csv(ts_path, index=False)

# plt.tight_layout()
# plt.subplots_adjust(wspace=0.35)  # increase horizontal space between subplots
# plt.show()


# # =========================
# #   Save CSVs
# # =========================
# # 1) Per-minute dataset with efficiency + output power (includes all scenarios)
# permin_df = pd.DataFrame(permin_rows, columns=[
#     "temp_group","scenario","minute","P_in_kW","eff_frac","eff_pct","P_out_kW","Batt_Temp_C","Amb_Temp_C"
# ])
# permin_csv_path = os.path.join(OUTPUT_DIR, "perminute_power_efficiency.csv")
# permin_df.to_csv(permin_csv_path, index=False)

# # 2) Summary metrics in exact order requested
# summary_df = pd.DataFrame(summary_rows)
# summary_df = summary_df[[
#     "temp_group","scenario","duration_min","avg_power_kW","total_energy_kWh","batt_temp_min_C","batt_temp_max_C"
# ]]
# summary_csv_path = os.path.join(OUTPUT_DIR, "summary_metrics.csv")
# summary_df.to_csv(summary_csv_path, index=False)

# print(f"Per-minute dataset saved to: {permin_csv_path}")
# print(f"Summary metrics saved to:   {summary_csv_path}")
# fig_path = os.path.join(OUTPUT_DIR, "fig10.png")
# fig.savefig(fig_path, dpi=300)
