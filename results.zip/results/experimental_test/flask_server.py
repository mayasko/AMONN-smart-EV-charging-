# server_ce2.py
# Flask endpoint for CANedge2 (CE2) S3-style uploads + optional MF4→CSV processing
import os
import re
import glob
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Set, Optional

from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename

import pandas as pd

# ======== Your local processing config ========
UPLOAD_ROOT   = r'D:\Research vision\Papers\Paper 2\Python codes\Implementation\Closed loop AMONN\uploads'
OUTPUT_ROOT   = r'D:\Research vision\Papers\Paper 2\Python codes\Implementation\Closed loop AMONN\output_csvs'
DBC_PATH      = r'D:\Research vision\Papers\Paper 2\Python codes\Implementation\Closed loop AMONN\CAN.dbc'
ALLOWED_EXTS  = {'.mf4', '.MF4'}
ASAM_MEMORY_MODE = "high"   # "high" for speed, "low"/"minimum" to save RAM
BUCKET_NAME = "ce2"         # MUST match CE2 "bucket" in config

os.makedirs(UPLOAD_ROOT, exist_ok=True)
os.makedirs(OUTPUT_ROOT, exist_ok=True)

# ======== Logging ========
log = logging.getLogger("ce2_server")
log.setLevel(logging.INFO)
console = logging.StreamHandler()
console.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
log.addHandler(console)

# ======== Optional MF4 decoding (safe if libs missing) ========
HAVE_MDF = False
HAVE_CANTOOLS = False
DB = None
INTERESTING_IDS: Dict[int, tuple] = {}

SIGNALS_TO_EXTRACT = [
    'RawBattCurrent132','BattVoltage132','BMSdissipation312',
    'BMSmaxPackTemperature','BMSminPackTemperature',
    'ChargeLinePower264','ChargeLineVoltage264','ChargeLineCurrent264',
    'SOCave292','VCFRONT_tempAmbient','VCRIGHT_tempAmbientRaw',
]
TARGET_SET: Set[str] = set(SIGNALS_TO_EXTRACT)

try:
    from asammdf import MDF  # type: ignore
    HAVE_MDF = True
except Exception as e:
    log.warning(f"asammdf not available, will skip MF4 decoding: {e}")

try:
    import cantools  # type: ignore
    HAVE_CANTOOLS = True
except Exception as e:
    log.warning(f"cantools not available, will skip MF4 decoding: {e}")

if HAVE_CANTOOLS:
    try:
        log.info("Loading DBC...")
        DB = cantools.database.load_file(DBC_PATH)  # type: ignore
        for msg in DB.messages:
            sig_names = {s.name for s in msg.signals}
            relevant = sig_names & TARGET_SET
            if relevant:
                INTERESTING_IDS[msg.frame_id] = (msg, relevant)
        if not INTERESTING_IDS:
            log.warning("No overlap between DBC signals and target set; decode will yield no channels.")
        else:
            log.info(f"DBC loaded. Interesting CAN IDs: {len(INTERESTING_IDS)}")
    except Exception as e:
        log.error(f"Failed to load DBC '{DBC_PATH}': {e}")
        DB = None

def _next_file_index(date_folder: str) -> int:
    max_idx = 0
    for p in glob.glob(os.path.join(date_folder, 'file*.csv')):
        m = re.search(r'file(\d+)\.csv$', p.replace('\\', '/'))
        if m:
            idx = int(m.group(1))
            if idx > max_idx:
                max_idx = idx
    return max_idx + 1

def process_mf4_file(mf4_path: str, output_root: str) -> dict:
    """
    Decode MF4 → 1-second CSV if libraries+DBC are available.
    Always returns a result dict; will report 'skipped' if decode not possible.
    """
    result = {"mf4_path": mf4_path, "saved_csv": None, "n_rows": 0, "status": "ok", "message": ""}

    if not os.path.isfile(mf4_path):
        return {"mf4_path": mf4_path, "status": "error", "message": "File not found."}

    if not (HAVE_MDF and HAVE_CANTOOLS and DB and INTERESTING_IDS):
        return {
            "mf4_path": mf4_path,
            "status": "ok",
            "message": "Saved MF4; decode skipped (asammdf/cantools/DBC missing or no interesting IDs)."
        }

    try:
        log.info(f"Decoding MF4: {mf4_path}")
        mdf = MDF(mf4_path, memory=ASAM_MEMORY_MODE)  # type: ignore

        mdf_start_time = mdf.header.start_time or datetime.now()
        date_str  = mdf_start_time.date().isoformat()
        month_str = mdf_start_time.strftime('%Y-%m')

        month_folder = os.path.join(output_root, month_str)
        date_folder  = os.path.join(month_folder, date_str)
        os.makedirs(date_folder, exist_ok=True)

        output_csv = os.path.join(date_folder, f'file{_next_file_index(date_folder)}.csv')
        buffers = {name: {"ts": [], "val": []} for name in SIGNALS_TO_EXTRACT}

        for group_index, group in enumerate(mdf.groups):
            try:
                channel_names = [ch.name for ch in group.channels]
            except Exception:
                continue
            if 'CAN_DataFrame' not in channel_names:
                continue

            try:
                rel_ts   = mdf.get('CAN_DataFrame', group=group_index).timestamps
                can_ids  = mdf.get('CAN_DataFrame.ID', group=group_index).samples.astype(int)
                data_arr = mdf.get('CAN_DataFrame.DataBytes', group=group_index).samples
            except Exception as e:
                log.warning(f"Group {group_index} missing expected channels: {e}")
                continue

            abs_ts = pd.to_datetime(mdf_start_time) + pd.to_timedelta(rel_ts, unit='s')

            for i, (cid, payload) in enumerate(zip(can_ids, data_arr)):
                info = INTERESTING_IDS.get(cid)
                if not info:
                    continue
                msg, relevant_signals = info
                try:
                    decoded = msg.decode(bytes(payload))
                except Exception:
                    continue
                if not decoded:
                    continue

                ts_i = abs_ts[i]
                for sname in relevant_signals:
                    if sname in decoded:
                        buffers[sname]["ts"].append(ts_i)
                        buffers[sname]["val"].append(decoded[sname])

        series_map = {}
        any_data = False
        for sname, buf in buffers.items():
            if buf["ts"]:
                any_data = True
                series_map[sname] = pd.Series(data=buf["val"], index=pd.DatetimeIndex(buf["ts"]))
        if not any_data:
            msg = "No target signals decoded in this file."
            log.warning(msg)
            return {"mf4_path": mf4_path, "status": "ok", "message": msg}

        combined = pd.concat(series_map, axis=1)
        combined.sort_index(inplace=True)
        combined_1s = combined.resample('1S').mean()
        combined_1s.reset_index(inplace=True)
        combined_1s.rename(columns={"index": "Timestamp"}, inplace=True)
        combined_1s.to_csv(output_csv, index=False)

        log.info(f"Saved CSV: {output_csv} (rows={len(combined_1s)})")
        return {
            "mf4_path": mf4_path,
            "saved_csv": output_csv,
            "n_rows": len(combined_1s),
            "status": "ok",
            "message": "Processed successfully."
        }
    except Exception as e:
        msg = f"Processing error: {e}"
        log.error(msg)
        return {"mf4_path": mf4_path, "status": "error", "message": msg}

# ======== Flask app ========
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_ROOT
app.config['MAX_CONTENT_LENGTH'] = None  # no explicit limit
app.url_map.strict_slashes = False

@app.before_request
def _log_incoming():
    log.info(f">>> {request.remote_addr} {request.method} {request.full_path} "
             f"CT={request.content_type} CL={request.content_length}")

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "ok"}), 200

def _sanitize_relpath(relpath: str) -> str:
    """
    Keep folder structure but make each segment Windows-safe.
    """
    parts = [p for p in relpath.replace("\\", "/").split("/") if p and p not in (".", "..")]
    safe_parts = [secure_filename(p) or "unnamed" for p in parts]
    return os.path.join(*safe_parts) if safe_parts else "unnamed"

def _save_stream_to(path: str, stream) -> Optional[str]:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as out:
            while True:
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
        return None
    except Exception as e:
        return str(e)

# Accept CE2 S3-style uploads: /<bucket>/<key>  (e.g., /ce2/device123/.../00000001.MF4)
@app.route('/<bucket>/<path:key>', methods=['PUT', 'POST'])
def s3_style_upload(bucket, key):
    if bucket != BUCKET_NAME:
        return f"Unknown bucket '{bucket}'", 404

    # If multipart, read the file stream; else raw body stream
    if 'file' in request.files:
        f = request.files['file']
        data_stream = f.stream
        orig_name = f.filename
    else:
        data_stream = request.stream
        orig_name = os.path.basename(key)

    rel_path = _sanitize_relpath(key if key else (orig_name or "upload.mf4"))
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], rel_path)

    err = _save_stream_to(save_path, data_stream)
    if err:
        log.error(f"Error saving file: {err}")
        return 'Internal server error while saving file', 500

    log.info(f"[{request.method}] File saved: {save_path}")

    # If this is an MF4, process it
    if Path(save_path).suffix.lower() == ".mf4":
        result = process_mf4_file(save_path, OUTPUT_ROOT)
        status_code = 200 if result.get("status") == "ok" else 500
        return jsonify(result), status_code

    return "OK", 200

# Handy manual upload for curl/Postman: multipart/form-data → /upload
@app.route('/upload', methods=['POST'])
def upload_manual():
    if 'file' not in request.files:
        return 'No file part in request', 400
    file = request.files['file']
    if file.filename == '':
        return 'No selected file', 400
    if Path(file.filename).suffix not in ALLOWED_EXTS:
        return f'Unsupported file type. Allowed: {", ".join(sorted(ALLOWED_EXTS))}', 400

    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    base = secure_filename(file.filename)
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{ts}_{base}")

    try:
        file.save(save_path)
        log.info(f"[POST] File saved: {save_path}")
    except Exception as e:
        log.error(f"Error saving file: {e}")
        return 'Internal server error while saving file', 500

    result = process_mf4_file(save_path, OUTPUT_ROOT)
    status_code = 200 if result.get("status") == "ok" else 500
    return jsonify(result), status_code

if __name__ == "__main__":
    # IMPORTANT: match CE2 port (=5050) and bind to all interfaces
    PORT = 5050
    log.info(f"Starting CE2 Flask server on 0.0.0.0:{PORT} (bucket='{BUCKET_NAME}')")
    app.run(host="0.0.0.0", port=PORT)
