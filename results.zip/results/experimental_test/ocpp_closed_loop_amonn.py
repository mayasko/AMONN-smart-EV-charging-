# # AMONN_CL (15 min, non-greedy): RFID-controlled start + 3-step ML schedule from Flask CSVs
# # Minute 0–1: 10 A, then 1–8: low ML candidate (kW→A/phase), 8–15: high ML candidate.
# # Greedy planner is DISABLED and left commented for reference.

# import asyncio, csv, logging, math, os, socket, time
# from datetime import datetime, timezone
# from glob import glob
# from pathlib import Path
# from typing import Optional, Tuple

# from http import HTTPStatus
# import numpy as np
# import pandas as pd
# import torch, joblib
# import websockets
# from http import HTTPStatus

# from ocpp.routing import on
# from ocpp.v16 import ChargePoint as CP
# from ocpp.v16 import call, call_result
# from ocpp.v16.enums import Action, RegistrationStatus, AuthorizationStatus

# # ================== Config ==================
# PORT = 8080
# DEFAULT_CP_ID = "ABB5"
# CONNECTOR_ID = 1

# # Charger/line assumptions
# CAR_MAX_PHASES = 3                      # 11 kW 3φ
# DEFAULT_V_LL = 400.0                    # V line-line
# PF = 1.0

# # Per-phase current limits (IEC typical for 11 kW 3φ)
# MIN_A_PER_PHASE = 6.0
# MAX_A_3PH = 16.0

# # ML defaults / search space (kW)
# DEFAULT_SOC = 50.0
# DEFAULT_AMB = 25.0
# MAX_POWER_3PH_KW = 11.0
# FULL_POWER_RANGE = np.linspace(4.0, MAX_POWER_3PH_KW, 20)
# TOP_N_CANDIDATES = 10

# # Profile timing
# PROFILE_DURATION = 15 * 60   # 900 s
# GRACE = 30                   # extra stop buffer

# # ==== Flask CSV (input telemetry) ====
# FLASK_OUTPUT_ROOT = r"D:\Research vision\Papers\Paper 2\Python codes\Implementation\Closed loop AMONN\output_csvs"
# INPUT_CSV_GLOB = str(Path(FLASK_OUTPUT_ROOT) / "*" / "*" / "*.csv")

# # Telemetry columns
# COL_SOC   = "SOCave292"
# COL_AMB   = "VCFRONT_tempAmbient"
# COL_BATT  = "BMSmaxPackTemperature"
# COL_PLINE = "ChargeLinePower264"  # W (not used in ML scoring here, but logged)

# # Logging & CSV (keep previous paths)
# LOG_DIR = r"D:\Research vision\Papers\Paper 2\Python codes\Implementation\Open Loop AMONN"
# os.makedirs(LOG_DIR, exist_ok=True)
# CSV_FILE = os.path.join(LOG_DIR, "PreTest_Validation.csv")

# # Additional OCPP/app log file
# APP_BASE = r"D:\Research vision\Papers\Paper 2\Python codes\Implementation"
# os.makedirs(APP_BASE, exist_ok=True)
# OCPP_LOG_FILE = os.path.join(APP_BASE, "ocpp_csms.log")

# # ================== Logging ==================
# fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
# root = logging.getLogger(); root.setLevel(logging.INFO)
# sh = logging.StreamHandler(); sh.setFormatter(fmt); root.addHandler(sh)
# from logging.handlers import RotatingFileHandler
# fh = RotatingFileHandler(OCPP_LOG_FILE, maxBytes=5_000_000, backupCount=3, encoding="utf-8")
# fh.setFormatter(fmt); root.addHandler(fh)
# logging.getLogger("ocpp").setLevel(logging.INFO)
# logging.getLogger("ocpp").addHandler(fh)
# logger = root

# if not os.path.exists(CSV_FILE):
#     with open(CSV_FILE, "w", newline="") as f:
#         csv.writer(f).writerow(["timestamp", "step", "requested_A", "L1_A", "L2_A", "L3_A"])

# # ================== Helpers ==================
# def local_ip() -> str:
#     try:
#         s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#         s.connect(("8.8.8.8", 80))
#         ip = s.getsockname()[0]
#     except Exception:
#         ip = "127.0.0.1"
#     finally:
#         try: s.close()
#         except Exception: pass
#     return ip

# def kw_to_amps_per_phase(kw, v_ll=DEFAULT_V_LL, phases=3, pf=PF):
#     w = max(0.0, float(kw)) * 1000.0
#     if phases == 3:
#         return w / (math.sqrt(3.0) * v_ll * pf)
#     return w / max(v_ll, 1.0)

# def clamp(x, lo, hi): return max(lo, min(hi, x))
# def _eq_kw(a_per_phase):  # rough equivalent total kW at DEFAULT_V_LL
#     return round(a_per_phase * math.sqrt(3) * DEFAULT_V_LL / 1000.0, 2)

# # ================== ML model ==================
# class ImprovedAttentionMultiOutputNet(torch.nn.Module):
#     def __init__(self):
#         super().__init__()
#         self.temp_attention = torch.nn.Sequential(
#             torch.nn.Linear(3,95), torch.nn.Tanh(),
#             torch.nn.Linear(95,3), torch.nn.Softmax(dim=1))
#         self.eff_attention = torch.nn.Sequential(
#             torch.nn.Linear(3,95), torch.nn.Tanh(),
#             torch.nn.Linear(95,3), torch.nn.Softmax(dim=1))
#         self.shared_layers = torch.nn.Sequential(
#             torch.nn.Linear(3,107), torch.nn.ReLU(),
#             torch.nn.Linear(107,114), torch.nn.ReLU(),
#             torch.nn.Linear(114,81), torch.nn.ReLU())
#         self.temp_branch = torch.nn.Sequential(
#             torch.nn.Linear(81,120), torch.nn.ReLU(),
#             torch.nn.Linear(120,121), torch.nn.ReLU(),
#             torch.nn.Linear(121,1))
#         self.efficiency_branch = torch.nn.Sequential(
#             torch.nn.Linear(81,38), torch.nn.ReLU(),
#             torch.nn.Linear(38,1))
#     def forward(self,x):
#         x_t = x * self.temp_attention(x)
#         shared_t = self.shared_layers(x_t)
#         temp = self.temp_branch(shared_t)
#         x_eff = torch.cat([x[:,:2], temp], dim=1)
#         x_e = x_eff * self.eff_attention(x_eff)
#         shared_e = self.shared_layers(x_e)
#         eff = self.efficiency_branch(shared_e)
#         return temp, eff

# MODEL_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\Model_Improved_Attention_charging_best.sd"
# IN_SCALER_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_input.pkl"
# OUT_SCALER_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_output.pkl"

# model = ImprovedAttentionMultiOutputNet()
# model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu")); model.eval()
# input_scaler  = joblib.load(IN_SCALER_PATH)
# output_scaler = joblib.load(OUT_SCALER_PATH)

# def _rank_top_candidates_with_scores(soc, amb, batt_meas_c=None,
#                                      full_range=FULL_POWER_RANGE, top_n=TOP_N_CANDIDATES):
#     X = np.asarray([[float(soc), float(pkw), float(amb)] for pkw in full_range], dtype=np.float32)
#     Xs = input_scaler.transform(X)
#     with torch.no_grad():
#         t_pred, e_pred = model(torch.tensor(Xs))
#         y = torch.cat([t_pred, e_pred], dim=1).numpy()
#     temp_eff = output_scaler.inverse_transform(y)
#     temps, effs = temp_eff[:, 0], temp_eff[:, 1]
#     if batt_meas_c is not None:
#         temps = np.maximum(temps, float(batt_meas_c))
#     scores = effs - np.maximum(0.0, temps - 35.0) * 0.5
#     idx = np.argsort(-scores)[:top_n]
#     return np.array(full_range, dtype=float)[idx], np.array(scores, dtype=float)[idx]

# # ================== Read Flask CSV telemetry ==================
# def _pick_latest_csv_file() -> Optional[str]:
#     paths = glob(INPUT_CSV_GLOB)
#     if not paths:
#         return None
#     paths.sort(key=lambda p: os.path.getmtime(p), reverse=True)
#     return paths[0]

# def _read_last_values_from_csv(path: str):
#     # light retry to avoid partial writes
#     for _ in range(3):
#         try:
#             df = pd.read_csv(path)
#             break
#         except Exception:
#             time.sleep(0.2)
#     else:
#         return None, None, None, None

#     soc  = float(df[COL_SOC].dropna().iloc[-1])   if COL_SOC   in df.columns and not df[COL_SOC].dropna().empty   else None
#     amb  = float(df[COL_AMB].dropna().iloc[-1])   if COL_AMB   in df.columns and not df[COL_AMB].dropna().empty   else None
#     batt = float(df[COL_BATT].dropna().iloc[-1])  if COL_BATT  in df.columns and not df[COL_BATT].dropna().empty  else None
#     pl_w = float(df[COL_PLINE].dropna().iloc[-1]) if COL_PLINE in df.columns and not df[COL_PLINE].dropna().empty else None
#     return soc, amb, batt, (pl_w/1000.0 if pl_w is not None else None)

# def get_live_inputs_from_flask() -> Tuple[float, float, Optional[float], Optional[float]]:
#     path = _pick_latest_csv_file()
#     if not path:
#         logger.warning("No CSV files found under %s — using defaults.", FLASK_OUTPUT_ROOT)
#         return DEFAULT_SOC, DEFAULT_AMB, None, None
#     soc, amb, batt, pl_kw = _read_last_values_from_csv(path)
#     if soc is None: soc = DEFAULT_SOC
#     if amb is None: amb = DEFAULT_AMB
#     logger.info("📥 CSV inputs (%s): SoC=%.1f%% Amb=%.1f°C Batt=%s°C Pline=%s kW",
#                 Path(path).name, soc, amb,
#                 f"{batt:.1f}" if batt is not None else "n/a",
#                 f"{pl_kw:.2f}" if pl_kw is not None else "n/a")
#     return soc, amb, batt, pl_kw

# # ================== Build the 15-min NON-GREEDY profile before connecting ==================
# def build_profile_steps_non_greedy() -> list:
#     soc, amb, batt, _ = get_live_inputs_from_flask()

#     # Show top-10 @ t0 for traceability
#     cands_kw, scores = _rank_top_candidates_with_scores(soc, amb, batt_meas_c=batt)
#     logger.info("📋 Top-10 ML candidates (kW @ t0): %s", [round(float(x), 2) for x in cands_kw.tolist()])
#     logger.info("📊 Candidate scores (@ t0): %s",   [round(float(s), 6)  for s in scores.tolist()])

#     lowest_kw  = float(np.min(cands_kw))
#     highest_kw = float(np.max(cands_kw))

#     # Convert to per-phase A and clamp
#     a_low  = clamp(kw_to_amps_per_phase(lowest_kw),  MIN_A_PER_PHASE, MAX_A_3PH)
#     a_high = clamp(kw_to_amps_per_phase(highest_kw), MIN_A_PER_PHASE, MAX_A_3PH)
#     a_low  = round(a_low,  1)
#     a_high = round(a_high, 1)

#     logger.info("🔧 Chosen setpoints → low: %.2f kW → %.1f A/phase | high: %.2f kW → %.1f A/phase",
#                 lowest_kw, a_low, highest_kw, a_high)

#     # Minute 0–1 → 10 A; 1–8 → a_low; 8–15 → a_high
#     steps = [
#         (0,    10.0),
#         (60,   a_low),
#         (480,  a_high),
#     ]

#     logger.info("🧩 PROFILE_STEPS(s,A): %s", steps)
#     logger.info("⚙️  Equivalent powers: 0–1≈%.2f kW | 1–8≈%.2f kW | 8–15≈%.2f kW",
#                 _eq_kw(steps[0][1]), _eq_kw(steps[1][1]), _eq_kw(steps[2][1]))
#     return steps

# # ---- GREEDY PLANNER (DISABLED) ---------------------------------------------
# # def plan_greedy_14min_profile() -> list:
# #     """Greedy per-minute ML planning for minutes 1..14 (disabled)."""
# #     ...
# # PROFILE_STEPS = plan_greedy_14min_profile()
# # ---------------------------------------------------------------------------

# PROFILE_STEPS = build_profile_steps_non_greedy()

# # ================== CSMS ==================
# class PreTestCS(CP):
#     def __init__(self, cp_id, connection):
#         super().__init__(cp_id, connection)
#         self.tx_id = None
#         self.start_time = None

#     @on(Action.boot_notification)
#     async def on_boot(self, **payload):
#         logger.info("✅ BootNotification from %s", self.id)
#         return call_result.BootNotification(
#             current_time=datetime.now(timezone.utc).isoformat(),
#             interval=30,
#             status=RegistrationStatus.accepted
#         )

#     @on(Action.status_notification)
#     async def on_status(self, **payload):
#         status = (payload.get("status") or "").lower()
#         logger.info("🔔 Status: %s", status)
#         if status == "preparing":
#             logger.info("⚡ EV plugged in. Waiting for RFID card swipe...")
#         return call_result.StatusNotification()

#     @on(Action.start_transaction)
#     async def on_start_tx(self, **payload):
#         tag = payload.get("id_tag") or payload.get("idTag")
#         self.tx_id = payload.get("transaction_id") or payload.get("transactionId") or 1
#         self.start_time = datetime.now()
#         logger.info("▶️ StartTransaction accepted with RFID: %s (tx_id=%s)", tag, self.tx_id)

#         # Apply one full TxDefaultProfile built beforehand (ABB honors this reliably)
#         profile = {
#             "chargingProfileId": 1,
#             "stackLevel": 0,
#             "chargingProfilePurpose": "TxDefaultProfile",
#             "chargingProfileKind": "Relative",
#             "chargingSchedule": {
#                 "duration": PROFILE_DURATION,
#                 "chargingRateUnit": "A",
#                 "chargingSchedulePeriod": [
#                     {"startPeriod": int(t), "limit": float(amp), "numberPhases": CAR_MAX_PHASES}
#                     for (t, amp) in PROFILE_STEPS
#                 ]
#             }
#         }
#         try:
#             resp = await self.call(call.SetChargingProfile(
#                 connector_id=CONNECTOR_ID,
#                 cs_charging_profiles=profile
#             ))
#             logger.info("📌 TxDefaultProfile enforced after RFID=%s → %s", tag, getattr(resp, "status", resp))
#         except Exception as e:
#             logger.warning("⚠️ SetChargingProfile failed: %s", e)

#         # Auto-stop after 900s + 30s grace
#         asyncio.create_task(self._auto_stop(PROFILE_DURATION + GRACE))

#         return call_result.StartTransaction(
#             transaction_id=self.tx_id,
#             id_tag_info={"status": AuthorizationStatus.accepted}
#         )

#     @on(Action.meter_values)
#     async def on_meter(self, **payload):
#         values = payload.get("meter_value", []) or payload.get("meterValue", [])
#         phases = {"L1": None, "L2": None, "L3": None}
#         for mv in values:
#             for sv in mv.get("sampled_value", []) or mv.get("sampledValue", []):
#                 meas = (sv.get("measurand") or "").lower()
#                 if "current.import" in meas and (sv.get("unit") == "A"):
#                     try:
#                         amp = float(sv["value"])
#                     except Exception:
#                         continue
#                     phase = sv.get("phase")
#                     if phase in phases:
#                         phases[phase] = amp

#         requested = None; step_id = None
#         if self.start_time:
#             elapsed = (datetime.now() - self.start_time).total_seconds()
#             for idx, (t, amp) in enumerate(PROFILE_STEPS, 1):
#                 if elapsed >= t:
#                     requested, step_id = amp, idx

#         if requested is not None:
#             logger.info("Validation step %s: requested=%.1f A | L1=%.2f | L2=%.2f | L3=%.2f",
#                         step_id, requested,
#                         phases["L1"] or 0.0, phases["L2"] or 0.0, phases["L3"] or 0.0)
#             try:
#                 with open(CSV_FILE, "a", newline="") as f:
#                     csv.writer(f).writerow([
#                         datetime.now().isoformat(timespec="seconds"),
#                         step_id, requested,
#                         phases["L1"] or 0.0, phases["L2"] or 0.0, phases["L3"] or 0.0
#                     ])
#             except Exception as e:
#                 logger.warning("CSV append failed: %s", e)

#         return call_result.MeterValues()

#     @on(Action.stop_transaction)
#     async def on_stop_tx(self, **payload):
#         logger.info("⏹ StopTransaction: %s", payload)
#         return call_result.StopTransaction()

#     @on(Action.heartbeat)
#     async def on_hb(self, **payload):
#         return call_result.Heartbeat(current_time=datetime.now(timezone.utc).isoformat())

#     async def _auto_stop(self, delay):
#         await asyncio.sleep(delay)
#         if self.tx_id:
#             try:
#                 logger.info("🛑 Auto-stopping transaction %s after %ds", self.tx_id, delay)
#                 await self.call(call.RemoteStopTransaction(transaction_id=self.tx_id))
#             except Exception as e:
#                 logger.warning("⚠️ Auto-stop failed: %s", e)

# # ================== Connection Handler ==================
# async def reject_http_requests(path, request_or_headers):
#     """
#     Accept WebSocket upgrades; return 426 for plain HTTP.
#     Works with websockets versions that pass either a Headers mapping
#     OR a Request object (which has a .headers mapping).
#     """
#     # Compat: get a mapping-like 'headers' with .get(...)
#     headers = getattr(request_or_headers, "headers", request_or_headers)

#     # If we can't read headers, allow the connection to proceed.
#     get = getattr(headers, "get", None)
#     if get is None:
#         return None

#     upgrade = (get("Upgrade") or get("upgrade") or "").lower()
#     connection = (get("Connection") or get("connection") or "").lower()

#     # Only reject if it's a plain HTTP request; let WS upgrades pass.
#     if "websocket" not in upgrade or "upgrade" not in connection:
#         body = b"This endpoint requires WebSocket (ocpp1.6)\n"
#         return (
#             HTTPStatus.UPGRADE_REQUIRED,
#             [("Content-Type", "text/plain; charset=utf-8")],
#             body,
#         )

#     return None


# async def on_connect(*args):
#     if len(args) == 2:
#         ws, path = args
#     else:
#         ws = args[0]
#         path = getattr(ws, "path", "/")
#     logger.info("🌐 WS connected: peer=%s path=%r", getattr(ws, "remote_address", None), path)
#     cp_id = (path or "/").strip("/") or DEFAULT_CP_ID
#     await PreTestCS(cp_id, ws).start()

# # ================== Main ==================
# async def main():
#     server = await websockets.serve(
#         on_connect,
#         host="0.0.0.0",
#         port=PORT,
#         subprotocols=["ocpp1.6", "ocpp1.6j", "ocpp1.6J"],
#         process_request=reject_http_requests
#     )
#     logger.info("🔌 CSMS ready at ws://%s:%d/ocppj16/%s", local_ip(), PORT, DEFAULT_CP_ID)
#     await server.wait_closed()

# if __name__ == "__main__":
#     asyncio.run(main())























# AMONN_CL (15 min, greedy prebuilt): RFID-controlled start + 14-min greedy ML schedule from Flask CSVs
# Minute 0–1: 10 A, then minutes 1–14: per-minute greedy ML choice (kW→A/phase), all baked into ONE TxDefaultProfile.

import asyncio, csv, logging, math, os, socket, time
from datetime import datetime, timezone
from glob import glob
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import pandas as pd
import torch, joblib
import websockets
from http import HTTPStatus

from ocpp.routing import on
from ocpp.v16 import ChargePoint as CP
from ocpp.v16 import call, call_result
from ocpp.v16.enums import Action, RegistrationStatus, AuthorizationStatus

# ================== Config ==================
PORT = 8080
DEFAULT_CP_ID = "ABB5"
CONNECTOR_ID = 1

# Charger/line assumptions
CAR_MAX_PHASES = 3                      # 11 kW 3φ
DEFAULT_V_LL = 400.0                    # V line-line
PF = 1.0

# Per-phase current limits (IEC typical for 11 kW 3φ)
MIN_A_PER_PHASE = 6.0
MAX_A_3PH = 16.0

# Battery capacity used to evolve SoC during greedy planning (adjust if needed)
BATTERY_KWH = 60.0

# ML defaults / search space (kW)
DEFAULT_SOC = 50.0
DEFAULT_AMB = 25.0
MAX_POWER_3PH_KW = 11.0
FULL_POWER_RANGE = np.linspace(4.0, MAX_POWER_3PH_KW, 20)
TOP_N_CANDIDATES = 10

# Profile timing
PROFILE_DURATION = 15 * 60   # 900 s total
GRACE = 30                   # extra stop buffer

# ==== Flask CSV (input telemetry) ====
FLASK_OUTPUT_ROOT = r"D:\Research vision\Papers\Paper 2\Python codes\Implementation\Closed loop AMONN\output_csvs"
INPUT_CSV_GLOB = str(Path(FLASK_OUTPUT_ROOT) / "*" / "*" / "*.csv")

# Telemetry columns
COL_SOC   = "SOCave292"
COL_AMB   = "VCFRONT_tempAmbient"
COL_BATT  = "BMSmaxPackTemperature"
COL_PLINE = "ChargeLinePower264"  # W

# Logging & CSV (keep your previous paths)
LOG_DIR = r"D:\Research vision\Papers\Paper 2\Python codes\Implementation\Open Loop AMONN"
os.makedirs(LOG_DIR, exist_ok=True)
CSV_FILE = os.path.join(LOG_DIR, "PreTest_Validation.csv")

# Additional OCPP/app log file
APP_BASE = r"D:\Research vision\Papers\Paper 2\Python codes\Implementation"
os.makedirs(APP_BASE, exist_ok=True)
OCPP_LOG_FILE = os.path.join(APP_BASE, "ocpp_csms.log")

# ================== Logging ==================
fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
root = logging.getLogger(); root.setLevel(logging.INFO)
sh = logging.StreamHandler(); sh.setFormatter(fmt); root.addHandler(sh)
from logging.handlers import RotatingFileHandler
fh = RotatingFileHandler(OCPP_LOG_FILE, maxBytes=5_000_000, backupCount=3, encoding="utf-8")
fh.setFormatter(fmt); root.addHandler(fh)
# Also hook library logger "ocpp"
logging.getLogger("ocpp").setLevel(logging.INFO)
logging.getLogger("ocpp").addHandler(fh)
logger = root

if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, "w", newline="") as f:
        csv.writer(f).writerow(["timestamp", "step", "requested_A", "L1_A", "L2_A", "L3_A"])

# ================== Helpers ==================
def local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        try: s.close()
        except Exception: pass
    return ip

def kw_to_amps_per_phase(kw, v_ll=DEFAULT_V_LL, phases=3, pf=PF):
    w = max(0.0, float(kw)) * 1000.0
    if phases == 3:
        return w / (math.sqrt(3.0) * v_ll * pf)
    return w / max(v_ll, 1.0)

def clamp(x, lo, hi): return max(lo, min(hi, x))

# ================== ML model ==================
class ImprovedAttentionMultiOutputNet(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.temp_attention = torch.nn.Sequential(
            torch.nn.Linear(3,95), torch.nn.Tanh(),
            torch.nn.Linear(95,3), torch.nn.Softmax(dim=1))
        self.eff_attention = torch.nn.Sequential(
            torch.nn.Linear(3,95), torch.nn.Tanh(),
            torch.nn.Linear(95,3), torch.nn.Softmax(dim=1))
        self.shared_layers = torch.nn.Sequential(
            torch.nn.Linear(3,107), torch.nn.ReLU(),
            torch.nn.Linear(107,114), torch.nn.ReLU(),
            torch.nn.Linear(114,81), torch.nn.ReLU())
        self.temp_branch = torch.nn.Sequential(
            torch.nn.Linear(81,120), torch.nn.ReLU(),
            torch.nn.Linear(120,121), torch.nn.ReLU(),
            torch.nn.Linear(121,1))
        self.efficiency_branch = torch.nn.Sequential(
            torch.nn.Linear(81,38), torch.nn.ReLU(),
            torch.nn.Linear(38,1))
    def forward(self,x):
        x_t = x * self.temp_attention(x)
        shared_t = self.shared_layers(x_t)
        temp = self.temp_branch(shared_t)
        x_eff = torch.cat([x[:,:2], temp], dim=1)
        x_e = x_eff * self.eff_attention(x_eff)
        shared_e = self.shared_layers(x_e)
        eff = self.efficiency_branch(shared_e)
        return temp, eff

MODEL_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\Model_Improved_Attention_charging_best.sd"
IN_SCALER_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_input.pkl"
OUT_SCALER_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_output.pkl"

model = ImprovedAttentionMultiOutputNet()
model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu")); model.eval()
input_scaler  = joblib.load(IN_SCALER_PATH)
output_scaler = joblib.load(OUT_SCALER_PATH)

def _eval_candidates_kw(soc: float, amb: float, candidates_kw: np.ndarray,
                        batt_meas_c: Optional[float] = None) -> float:
    X = np.asarray([[soc, pkw, amb] for pkw in candidates_kw], dtype=np.float32)
    Xs = input_scaler.transform(X)
    with torch.no_grad():
        t_pred, e_pred = model(torch.tensor(Xs))
        y = torch.cat([t_pred, e_pred], dim=1).numpy()
    temp_eff = output_scaler.inverse_transform(y)
    temps = temp_eff[:, 0]
    effs  = temp_eff[:, 1]
    if batt_meas_c is not None:
        temps = np.maximum(temps, batt_meas_c)
    scores = effs - np.maximum(0.0, temps - 35.0) * 0.5
    return float(candidates_kw[int(np.argmax(scores))])

def _rank_top_candidates_with_scores(soc, amb, batt_meas_c=None,
                                     full_range=FULL_POWER_RANGE, top_n=TOP_N_CANDIDATES):
    X = np.asarray([[soc, pkw, amb] for pkw in full_range], dtype=np.float32)
    Xs = input_scaler.transform(X)
    with torch.no_grad():
        t_pred, e_pred = model(torch.tensor(Xs))
        y = torch.cat([t_pred, e_pred], dim=1).numpy()
    temp_eff = output_scaler.inverse_transform(y)
    temps, effs = temp_eff[:, 0], temp_eff[:, 1]
    if batt_meas_c is not None:
        temps = np.maximum(temps, batt_meas_c)
    scores = effs - np.maximum(0.0, temps - 35.0) * 0.5
    idx = np.argsort(-scores)[:top_n]
    return np.array(full_range, dtype=float)[idx], np.array(scores, dtype=float)[idx]

# ================== Read Flask CSV telemetry ==================
def _pick_latest_csv_file() -> Optional[str]:
    paths = glob(INPUT_CSV_GLOB)
    if not paths:
        return None
    paths.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return paths[0]

def _read_last_values_from_csv(path: str):
    # light retry to avoid partial writes
    for _ in range(3):
        try:
            df = pd.read_csv(path)
            break
        except Exception:
            time.sleep(0.2)
    else:
        return None, None, None, None

    soc  = float(df[COL_SOC].dropna().iloc[-1])   if COL_SOC   in df.columns and not df[COL_SOC].dropna().empty   else None
    amb  = float(df[COL_AMB].dropna().iloc[-1])   if COL_AMB   in df.columns and not df[COL_AMB].dropna().empty   else None
    batt = float(df[COL_BATT].dropna().iloc[-1])  if COL_BATT  in df.columns and not df[COL_BATT].dropna().empty  else None
    pl_w = float(df[COL_PLINE].dropna().iloc[-1]) if COL_PLINE in df.columns and not df[COL_PLINE].dropna().empty else None
    return soc, amb, batt, (pl_w/1000.0 if pl_w is not None else None)

def get_live_inputs_from_flask() -> Tuple[float, float, Optional[float], Optional[float]]:
    path = _pick_latest_csv_file()
    if not path:
        logger.warning("No CSV files found under %s — using defaults.", FLASK_OUTPUT_ROOT)
        return DEFAULT_SOC, DEFAULT_AMB, None, None
    soc, amb, batt, pl_kw = _read_last_values_from_csv(path)
    if soc is None: soc = DEFAULT_SOC
    if amb is None: amb = DEFAULT_AMB
    logger.info("📥 CSV inputs (%s): SoC=%.1f%% Amb=%.1f°C Batt=%s°C Pline=%s kW",
                Path(path).name, soc, amb,
                f"{batt:.1f}" if batt is not None else "n/a",
                f"{pl_kw:.2f}" if pl_kw is not None else "n/a")
    return soc, amb, batt, pl_kw

# ================== Build the full 15-min greedy profile before connecting ==================
def plan_greedy_14min_profile() -> list:
    """Return PROFILE_STEPS list of (startSecond, limitA) with:
       - t=0..60s: 10 A
       - t=60..900s: 14 steps chosen greedily per minute using ML (with SoC updated)."""
    soc, amb, batt, _ = get_live_inputs_from_flask()

    # For logging: show top-10 at start state
    cands_kw0, scores0 = _rank_top_candidates_with_scores(soc, amb, batt_meas_c=batt)
    logger.info("📋 Top-10 ML candidates (kW @ t0): %s", [round(float(x), 2) for x in cands_kw0.tolist()])
    logger.info("📊 Candidate scores (@ t0): %s",   [round(float(s), 6)  for s in scores0.tolist()])

    steps = [(0, 10.0)]  # minute 0–1 fixed at 10 A
    t = 60

    # Greedy for minutes 1..14
    for minute in range(1, 15):
        best_kw = _eval_candidates_kw(soc=soc, amb=amb, candidates_kw=FULL_POWER_RANGE, batt_meas_c=batt)
        # Convert to A/phase and clamp to charger constraints
        amps = kw_to_amps_per_phase(best_kw)
        amps = clamp(amps, MIN_A_PER_PHASE, MAX_A_3PH)
        amps = round(float(amps), 1)
        steps.append((t, amps))

        # Evolve SoC with a simple energy balance (1 minute at chosen kW)
        # ΔSoC[%] ≈ (kW * (1/60) h) / BATTERY_KWH * 100
        if BATTERY_KWH > 0:
            soc += float(best_kw) * (100.0 / (60.0 * BATTERY_KWH))
            soc = float(clamp(soc, 0.0, 100.0))

        logger.info("🧠 Greedy m%02d @t=%3ds → %.2f kW (%.1f A/φ), next SoC≈%.1f%%", minute, t, best_kw, amps, soc)
        t += 60

    # Sanity: last start should be 840s (covers 840–900)
    return steps

PROFILE_STEPS = plan_greedy_14min_profile()

def _eq_kw(a): return round(a * math.sqrt(3) * DEFAULT_V_LL / 1000.0, 2)
logger.info("🧩 PROFILE_STEPS(s,A): %s", PROFILE_STEPS)
logger.info("⚙️  Equivalent powers (first 4): %s",
            [ _eq_kw(amp) for (_,amp) in PROFILE_STEPS[:4] ])

# ================== CSMS ==================
class PreTestCS(CP):
    def __init__(self, cp_id, connection):
        super().__init__(cp_id, connection)
        self.tx_id = None
        self.start_time = None

    @on(Action.boot_notification)
    async def on_boot(self, **payload):
        logger.info("✅ BootNotification from %s", self.id)
        return call_result.BootNotification(
            current_time=datetime.now(timezone.utc).isoformat(),
            interval=30,
            status=RegistrationStatus.accepted
        )

    @on(Action.status_notification)
    async def on_status(self, **payload):
        status = (payload.get("status") or "").lower()
        logger.info("🔔 Status: %s", status)
        if status == "preparing":
            logger.info("⚡ EV plugged in. Waiting for RFID card swipe...")
        return call_result.StatusNotification()

    @on(Action.start_transaction)
    async def on_start_tx(self, **payload):
        tag = payload.get("id_tag") or payload.get("idTag")
        self.tx_id = payload.get("transaction_id") or payload.get("transactionId") or 1
        self.start_time = datetime.now()
        logger.info("▶️ StartTransaction accepted with RFID: %s (tx_id=%s)", tag, self.tx_id)

        # Apply one full TxDefaultProfile built beforehand (ABB honors this reliably)
        profile = {
            "chargingProfileId": 1,
            "stackLevel": 0,
            "chargingProfilePurpose": "TxDefaultProfile",
            "chargingProfileKind": "Relative",
            "chargingSchedule": {
                "duration": PROFILE_DURATION,
                "chargingRateUnit": "A",
                "chargingSchedulePeriod": [
                    {"startPeriod": int(t), "limit": float(amp), "numberPhases": CAR_MAX_PHASES}
                    for (t, amp) in PROFILE_STEPS
                ]
            }
        }
        try:
            resp = await self.call(call.SetChargingProfile(
                connector_id=CONNECTOR_ID,
                cs_charging_profiles=profile
            ))
            logger.info("📌 TxDefaultProfile enforced after RFID=%s → %s", tag, getattr(resp, "status", resp))
        except Exception as e:
            logger.warning("⚠️ SetChargingProfile failed: %s", e)

        # Auto-stop after 900s + 30s grace
        asyncio.create_task(self._auto_stop(PROFILE_DURATION + GRACE))

        return call_result.StartTransaction(
            transaction_id=self.tx_id,
            id_tag_info={"status": AuthorizationStatus.accepted}
        )

    @on(Action.meter_values)
    async def on_meter(self, **payload):
        values = payload.get("meter_value", []) or payload.get("meterValue", [])
        phases = {"L1": None, "L2": None, "L3": None}
        for mv in values:
            for sv in mv.get("sampled_value", []) or mv.get("sampledValue", []):
                meas = (sv.get("measurand") or "").lower()
                if "current.import" in meas and (sv.get("unit") == "A"):
                    try:
                        amp = float(sv["value"])
                    except Exception:
                        continue
                    phase = sv.get("phase")
                    if phase in phases:
                        phases[phase] = amp

        requested = None; step_id = None
        if self.start_time:
            elapsed = (datetime.now() - self.start_time).total_seconds()
            for idx, (t, amp) in enumerate(PROFILE_STEPS, 1):
                if elapsed >= t:
                    requested, step_id = amp, idx

        if requested is not None:
            logger.info("Validation step %s: requested=%.1f A | L1=%.2f | L2=%.2f | L3=%.2f",
                        step_id, requested,
                        phases["L1"] or 0.0, phases["L2"] or 0.0, phases["L3"] or 0.0)
            try:
                with open(CSV_FILE, "a", newline="") as f:
                    csv.writer(f).writerow([
                        datetime.now().isoformat(timespec="seconds"),
                        step_id, requested,
                        phases["L1"] or 0.0, phases["L2"] or 0.0, phases["L3"] or 0.0
                    ])
            except Exception as e:
                logger.warning("CSV append failed: %s", e)

        return call_result.MeterValues()

    @on(Action.stop_transaction)
    async def on_stop_tx(self, **payload):
        logger.info("⏹ StopTransaction: %s", payload)
        return call_result.StopTransaction()

    @on(Action.heartbeat)
    async def on_hb(self, **payload):
        return call_result.Heartbeat(current_time=datetime.now(timezone.utc).isoformat())

    async def _auto_stop(self, delay):
        await asyncio.sleep(delay)
        if self.tx_id:
            try:
                logger.info("🛑 Auto-stopping transaction %s after %ds", self.tx_id, delay)
                await self.call(call.RemoteStopTransaction(transaction_id=self.tx_id))
            except Exception as e:
                logger.warning("⚠️ Auto-stop failed: %s", e)

# ================== Connection Handler ==================
async def reject_http_requests(path, request_or_headers):
    """
    Accept WebSocket upgrades; return 426 for plain HTTP.
    Works with websockets versions that pass either a Headers mapping
    OR a Request object (which has a .headers mapping).
    """
    # Compat: get a mapping-like 'headers' with .get(...)
    headers = getattr(request_or_headers, "headers", request_or_headers)

    # If we can't read headers, allow the connection to proceed.
    get = getattr(headers, "get", None)
    if get is None:
        return None

    upgrade = (get("Upgrade") or get("upgrade") or "").lower()
    connection = (get("Connection") or get("connection") or "").lower()

    # Only reject if it's a plain HTTP request; let WS upgrades pass.
    if "websocket" not in upgrade or "upgrade" not in connection:
        body = b"This endpoint requires WebSocket (ocpp1.6)\n"
        return (
            HTTPStatus.UPGRADE_REQUIRED,
            [("Content-Type", "text/plain; charset=utf-8")],
            body,
        )

    return None

async def on_connect(*args):
    if len(args) == 2:
        ws, path = args
    else:
        ws = args[0]
        path = getattr(ws, "path", "/")
    logger.info("🌐 WS connected: peer=%s path=%r", getattr(ws, "remote_address", None), path)
    cp_id = (path or "/").strip("/") or DEFAULT_CP_ID
    await PreTestCS(cp_id, ws).start()

# ================== Main ==================
async def main():
    server = await websockets.serve(
        on_connect,
        host="0.0.0.0",
        port=PORT,
        subprotocols=["ocpp1.6", "ocpp1.6j", "ocpp1.6J"],
        process_request=reject_http_requests
    )
    logger.info("🔌 CSMS ready at ws://%s:%d/ocppj16/%s", local_ip(), PORT, DEFAULT_CP_ID)
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())



































