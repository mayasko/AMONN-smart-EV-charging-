# OPEN LOOP AMONN_OL (15 min): RFID-controlled start + stepped profile computed by ML first
import asyncio, csv, logging, os, math
from datetime import datetime, timezone

import numpy as np
import torch, joblib
import websockets
from ocpp.routing import on
from ocpp.v16 import ChargePoint as CP
from ocpp.v16 import call, call_result
from ocpp.v16.enums import Action, RegistrationStatus, AuthorizationStatus

# ================== Config ==================
PORT = 8080
DEFAULT_CP_ID = "ABB5"
CONNECTOR_ID = 1

# Charger/line assumptions
CAR_MAX_PHASES = 3          # 11 kW 3φ
DEFAULT_V_LL = 400.0        # V_line-line
PF = 1.0

# Per-phase current limits (IEC: 6–16 A typical for 11 kW 3φ)
MIN_A_PER_PHASE = 6.0
MAX_A_3PH = 16.0

# ML defaults / search space (kW)
DEFAULT_SOC = 50.0
DEFAULT_AMB = 25.0
MAX_POWER_3PH_KW = 11.0
FULL_POWER_RANGE = np.linspace(4.0, MAX_POWER_3PH_KW, 20)
TOP_N_CANDIDATES = 10

# --- Logging & CSV (unchanged paths) ---
LOG_DIR = r"D:\Research vision\Papers\Paper 2\Python codes\Implementation\Open Loop AMONN"
os.makedirs(LOG_DIR, exist_ok=True)
CSV_FILE = os.path.join(LOG_DIR, "PreTest_Validation.csv")  # keep same filename for continuity

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, "w", newline="") as f:
        csv.writer(f).writerow(
            ["timestamp", "step", "requested_A", "L1_A", "L2_A", "L3_A"]
        )

# ================== Helper fns ==================
def kw_to_amps_per_phase(kw, v_ll=DEFAULT_V_LL, phases=3, pf=PF):
    """Per-phase RMS current for total three-phase power."""
    w = max(0.0, float(kw)) * 1000.0
    if phases == 3:
        return w / (math.sqrt(3.0) * v_ll * pf)
    return w / max(v_ll, 1.0)

def clamp(x, lo, hi): return max(lo, min(hi, x))

# ================== ML model (compute profile first) ==================
class ImprovedAttentionMultiOutputNet(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.temp_attention = torch.nn.Sequential(
            torch.nn.Linear(3,95), torch.nn.Tanh(),
            torch.nn.Linear(95,3), torch.nn.Softmax(dim=1))
        self.eff_attention = torch.nn.Sequential(
            torch.nn.Linear(3,95), torch.nn.Tanh(),
            torch.nn.Linear(95,3), torch.nn.Softmax(dim=1))
        self.shared_layers = torch.nn.Sequential(
            torch.nn.Linear(3,107), torch.nn.ReLU(),
            torch.nn.Linear(107,114), torch.nn.ReLU(),
            torch.nn.Linear(114,81), torch.nn.ReLU())
        self.temp_branch = torch.nn.Sequential(
            torch.nn.Linear(81,120), torch.nn.ReLU(),
            torch.nn.Linear(120,121), torch.nn.ReLU(),
            torch.nn.Linear(121,1))
        self.efficiency_branch = torch.nn.Sequential(
            torch.nn.Linear(81,38), torch.nn.ReLU(),
            torch.nn.Linear(38,1))
    def forward(self,x):
        x_t = x * self.temp_attention(x)
        shared_t = self.shared_layers(x_t)
        temp = self.temp_branch(shared_t)
        x_eff = torch.cat([x[:,:2], temp], dim=1)
        x_e = x_eff * self.eff_attention(x_eff)
        shared_e = self.shared_layers(x_e)
        eff = self.efficiency_branch(shared_e)
        return temp, eff

# Paths to your trained assets (unchanged)
MODEL_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\Model_Improved_Attention_charging_best.sd"
IN_SCALER_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_input.pkl"
OUT_SCALER_PATH = r"D:\Research vision\Papers\Paper 2\Python codes\Simualtion framework\scaler_improved_attention_output.pkl"

def rank_top_candidates_with_scores(soc, amb, full_range=FULL_POWER_RANGE, top_n=TOP_N_CANDIDATES):
    X = np.asarray([[soc, pkw, amb] for pkw in full_range], dtype=np.float32)
    Xs = input_scaler.transform(X)
    with torch.no_grad():
        t_pred, e_pred = model(torch.tensor(Xs))
        y = torch.cat([t_pred, e_pred], dim=1).numpy()
    temp_eff = output_scaler.inverse_transform(y)
    temps, effs = temp_eff[:, 0], temp_eff[:, 1]
    scores = effs - np.maximum(0.0, temps - 35.0) * 0.5
    idx = np.argsort(-scores)[:top_n]
    return np.array(full_range, dtype=float)[idx], np.array(scores, dtype=float)[idx]

# Load model + scalers, compute A setpoints BEFORE connecting to charger
model = ImprovedAttentionMultiOutputNet()
model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu")); model.eval()
input_scaler  = joblib.load(IN_SCALER_PATH)
output_scaler = joblib.load(OUT_SCALER_PATH)

cands_kw, cand_scores = rank_top_candidates_with_scores(DEFAULT_SOC, DEFAULT_AMB)
lowest_kw  = float(np.min(cands_kw))
highest_kw = float(np.max(cands_kw))

# Convert to per-phase A and clamp
a_low  = clamp(kw_to_amps_per_phase(lowest_kw),  MIN_A_PER_PHASE, MAX_A_3PH)
a_high = clamp(kw_to_amps_per_phase(highest_kw), MIN_A_PER_PHASE, MAX_A_3PH)

logging.info("📋 Top-10 ML candidates (kW): %s", np.round(cands_kw, 2).tolist())
logging.info("📊 Candidate scores: %s", np.round(cand_scores, 4).tolist())
logging.info("🔧 Chosen setpoints → low: %.2f kW → %.1f A/phase | high: %.2f kW → %.1f A/phase",
             lowest_kw, a_low, highest_kw, a_high)

# ================== AMONN_OL 15-min profile (built from ML) ==================
# Minute 0–1 → 10 A; 1–8 → a_low; 8–15 → a_high
PROFILE_STEPS = [
    (0,    10.0),       # 0–60s: 10 A
    (60,   round(a_low,  1)),  # 60–480s: lowest ML candidate
    (480,  round(a_high, 1)),  # 480–900s: highest ML candidate
]
PROFILE_DURATION = 15 * 60   # 900 s
GRACE = 30                   # extra 30 s

logging.info("🧩 Built PROFILE_STEPS (s, A): %s", PROFILE_STEPS)
def _eq_kw(a): return round(a * math.sqrt(3) * DEFAULT_V_LL / 1000.0, 2)
logging.info("⚙️  Equivalent powers: 0–1min ≈ %.2f kW | 1–8min ≈ %.2f kW | 8–15min ≈ %.2f kW",
             _eq_kw(PROFILE_STEPS[0][1]), _eq_kw(PROFILE_STEPS[1][1]), _eq_kw(PROFILE_STEPS[2][1]))

# ================== CSMS (unchanged behavior) ==================
class PreTestCS(CP):
    def __init__(self, cp_id, connection):
        super().__init__(cp_id, connection)
        self.tx_id = None
        self.start_time = None

    @on(Action.boot_notification)
    async def on_boot(self, **payload):
        logging.info("✅ BootNotification from %s", self.id)
        return call_result.BootNotification(
            current_time=datetime.now(timezone.utc).isoformat(),
            interval=30,
            status=RegistrationStatus.accepted
        )

    @on(Action.status_notification)
    async def on_status(self, **payload):
        status = payload.get("status", "").lower()
        logging.info("🔔 Status: %s", status)
        if status == "preparing":
            logging.info("⚡ EV plugged in. Waiting for RFID card swipe...")
        return call_result.StatusNotification()

    @on(Action.start_transaction)
    async def on_start_tx(self, **payload):
        tag = payload.get("id_tag")
        self.tx_id = payload.get("transaction_id") or 1
        self.start_time = datetime.now()

        logging.info("▶️ StartTransaction accepted with RFID: %s", tag)

        # Apply TxDefaultProfile after RFID is provided (same technique as your working code)
        profile = {
            "chargingProfileId": 1,
            "stackLevel": 0,
            "chargingProfilePurpose": "TxDefaultProfile",
            "chargingProfileKind": "Relative",
            "chargingSchedule": {
                "duration": PROFILE_DURATION,
                "chargingRateUnit": "A",
                "chargingSchedulePeriod": [
                    {"startPeriod": t, "limit": amp, "numberPhases": 3}
                    for t, amp in PROFILE_STEPS
                ]
            }
        }
        asyncio.create_task(self.call(call.SetChargingProfile(
            connector_id=CONNECTOR_ID,
            cs_charging_profiles=profile
        )))
        logging.info("📌 TxDefaultProfile enforced after RFID=%s", tag)

        # Auto-stop after 900s + 30s grace
        asyncio.create_task(self._auto_stop(PROFILE_DURATION + GRACE))

        return call_result.StartTransaction(
            transaction_id=self.tx_id,
            id_tag_info={"status": AuthorizationStatus.accepted}
        )

    @on(Action.meter_values)
    async def on_meter(self, **payload):
        # Parse phase currents
        values = payload.get("meter_value", []) or payload.get("meterValue", [])
        phases = {"L1": None, "L2": None, "L3": None}
        for mv in values:
            for sv in mv.get("sampled_value", []) or mv.get("sampledValue", []):
                if sv.get("measurand") in ("Current.Import", "Current.Import"):  # keep simple
                    if sv.get("unit") == "A":
                        try:
                            amp = float(sv["value"])
                        except:
                            continue
                        phase = sv.get("phase")
                        if phase in phases:
                            phases[phase] = amp

        # Determine requested value based on elapsed time and PROFILE_STEPS
        requested = None
        step_id = None
        if self.start_time:
            elapsed = (datetime.now() - self.start_time).total_seconds()
            for idx, (t, amp) in enumerate(PROFILE_STEPS, 1):
                if elapsed >= t:
                    requested, step_id = amp, idx

        if requested is not None:
            logging.info(
                "Validation step %s: requested=%.1f A | L1=%.2f | L2=%.2f | L3=%.2f",
                step_id, requested,
                phases["L1"] or 0.0,
                phases["L2"] or 0.0,
                phases["L3"] or 0.0
            )
            with open(CSV_FILE, "a", newline="") as f:
                csv.writer(f).writerow([
                    datetime.now().isoformat(timespec="seconds"),
                    step_id, requested,
                    phases["L1"] or 0.0,
                    phases["L2"] or 0.0,
                    phases["L3"] or 0.0
                ])

        return call_result.MeterValues()

    @on(Action.stop_transaction)
    async def on_stop_tx(self, **payload):
        logging.info("⏹ StopTransaction: %s", payload)
        return call_result.StopTransaction()

    @on(Action.heartbeat)
    async def on_hb(self, **payload):
        return call_result.Heartbeat(
            current_time=datetime.now(timezone.utc).isoformat()
        )

    async def _auto_stop(self, delay):
        await asyncio.sleep(delay)
        if self.tx_id:
            try:
                logging.info("🛑 Auto-stopping transaction %s after %ds", self.tx_id, delay)
                await self.call(call.RemoteStopTransaction(transaction_id=self.tx_id))
            except Exception as e:
                logging.warning("⚠️ Auto-stop failed: %s", e)

# ================== Connection Handler ==================
async def on_connect(*args):
    if len(args) == 2:
        ws, path = args
    else:
        ws = args[0]
        path = getattr(ws, "path", "/")
    logging.info("🌐 WS connected: peer=%s path=%r", ws.remote_address, path)
    cp_id = (path or "/").strip("/") or DEFAULT_CP_ID
    await PreTestCS(cp_id, ws).start()

# ================== Main ==================
async def main():
    server = await websockets.serve(
        on_connect,
        host="0.0.0.0",
        port=PORT,
        subprotocols=["ocpp1.6", "ocpp1.6j", "ocpp1.6J"],
    )
    logging.info("🔌 CSMS ready at ws://192.168.137.6:%d/ocppj16/%s", PORT, DEFAULT_CP_ID)
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())















